<header class=' header-main'>
        <?php $__env->startComponent('site.partials._nav-main'); ?>
        <?php echo $__env->renderComponent(); ?>
        <section class="container-fluid  d-flex justify-content-center align-items-center header-main-wrapper  ">
            <?php echo e($slot); ?>

        </section>
        
</header><?php /**PATH /home/victor/desarrollo/gomezsite2020/resources/views/site/partials/_header.blade.php ENDPATH**/ ?>