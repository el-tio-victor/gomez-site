

<?php $__env->startSection('title-doc',' Categorías'); ?>

<?php $__env->startSection('title'); ?>
    Tags
<?php $__env->stopSection(); ?>

<?php $__env->startSection('breadcrumb-items'); ?>
    <li class="breadcrumb-item active">Tags</li>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>
<?php echo $__env->make('flash::message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="row">
        <section class='col-md-6 col-lg-7 '>
            <?php $__env->startComponent('dashboard.partials.card', ['class_card'=>'card-outline card-primary']); ?>
                <?php $__env->slot('header','Todos los tags'); ?>
                <?php $__env->slot('tools'); ?>
                    <?php echo Form::open(['route'=>'tags.index','method'=>'GET','class'=>'']); ?>

                    <div class='d-flex ' style='border:solid .1rem #e9ecef !important;'>
                        
                        <div class="input-group input-group-sm">
                            <?php echo Form::text('name',null,['class'=>'col','placeholder'=>'Buscar tag', "aria-describedby"=>"search"]); ?>

                            <span class="input-group-append " id="search">
                                <button class="btn btn-flat btn-primary" type='button'> <i class="fas fa-search"> </i></button>
                            </span>
                        </div>
                    </div>
                    <?php echo Form::close(); ?>

                <?php $__env->endSlot(); ?>
                <?php $__env->slot('body'); ?>
                    <a class='align-bottom btn btn-sm btn-success' href=" <?php echo e(route('tags.index')); ?> "><span class=""><i class="mr-1 fas fa-plus"></i>Nuevo Tag</span></a>
                    <table class="table">
                        <thead>
                            <tr>
                                <th scope="col">#</th>
                                <th scope="col">Nombre</th>
                                <th scope="col">Acciones</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <th scope="row"><?php echo e($loop->iteration); ?></th>
                                    <td> <?php echo e($tag->name); ?> </td>
                                    <td>
                                        <div class="btn-group  btn-small">
                                            <a class='btn pl-1 pr-1 pt-0 pb-0 btn-danger' 
                                            onclick="return confirm('Deseas eliminar este elemento?')" 
                                            href=" <?php echo e(route('dashboard.tags.destroy',$tag->id)); ?> ">
                                            <span class='fas fa-trash'></span>
                                            </a>
                                            <a class='btn pl-1 pr-1 pt-0 pb-0 btn-warning' href=" <?php echo e(route('tags.edit',$tag->id)); ?> ">
                                            <span class='fas fa-edit'></span>
                                            </a>
                                        </div>
                                        
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                <?php $__env->endSlot(); ?>
                <?php $__env->slot('footer'); ?>
                    <nav aria-label="Page navigation">
                        <?php echo $tags->render(); ?>

                    </nav>
                <?php $__env->endSlot(); ?>
            <?php echo $__env->renderComponent(); ?>
        </section>
        <section class='col-md-6 col-lg-5 '>
            <div>
                <?php $__env->startComponent('dashboard.partials.card', ['class_card'=>'card-outline card-success']); ?>
                    <?php $__env->slot('header','Nuevo tag'); ?><?php $__env->slot('tools',''); ?>
                    <?php $__env->slot('body'); ?>
                        <?php if($tag_edit === null): ?>
                            <?php echo $__env->make('dashboard.blog.tags._form',['route'=>'tags.store', 'method'=>'POST' ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        <?php endif; ?>
                    <?php $__env->endSlot(); ?>
                    <?php $__env->slot('footer',''); ?>
                <?php echo $__env->renderComponent(); ?>
            </div>
            <div>
                <?php $__env->startComponent('dashboard.partials.card', ['class_card'=>'card-outline card-warning']); ?>
                    <?php $__env->slot('header','Editar tag'); ?><?php $__env->slot('tools',''); ?>
                    <?php $__env->slot('body'); ?>
                        <?php if($tag_edit != null): ?>
                            <?php echo $__env->make('dashboard.blog.tags._form',['route'=>['tags.update',$tag],'method'=>'PUT'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        <?php endif; ?>   
                    <?php $__env->endSlot(); ?>
                    <?php $__env->slot('footer',''); ?>
                <?php echo $__env->renderComponent(); ?>
            </div>
        </section>
</div>
   
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script>$('div.alert').not('.alert-important').delay(3000).fadeOut(350);</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/vagrant/gomezsite2020/resources/views/dashboard/blog/tags/index.blade.php ENDPATH**/ ?>