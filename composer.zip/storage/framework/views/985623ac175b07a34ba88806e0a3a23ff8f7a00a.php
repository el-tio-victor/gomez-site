
<?php $__currentLoopData = $works; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $work): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
       
            <?php $__env->startComponent('site.portfolio.partials.work'); ?>
                <?php $__env->slot('title',$work->title); ?>
                <?php $__env->slot('services', $work->services); ?>
                <?php $__env->slot('detail',$work->detail); ?>
                <?php $__env->slot('url', $work->url ); ?>
                <?php $__env->slot('images', $work->images()->where('image_main',1)->get() ); ?>
                <?php $__env->slot('tt', $work->technologyTool); ?>
                <?php $__env->slot('work_slug', $work->slug ); ?>
            <?php echo $__env->renderComponent(); ?>
        
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>





<?php /**PATH /home/vagrant/gomezsite2020/resources/views/site/home/partials/contentWorks.blade.php ENDPATH**/ ?>