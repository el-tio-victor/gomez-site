

<?php $__env->startSection('title-doc','Nuevo  Artículo'); ?>

<?php $__env->startSection('title'); ?>
    Nuevo Artículo
<?php $__env->stopSection(); ?>

<?php $__env->startSection('breadcrumb-items'); ?>
    <li class="breadcrumb-item "><a href="dashboard.articles" class="">Artículos</a></li>
    <li class="breadcrumb-item active">Crear</li>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('dashboard.blog.articles._form',['route'=>'articles.store', 'article'=> null,'method' => 'POST'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<script src="<?php echo e(asset('plugins/summernote/summernote-bs4.min.js')); ?>"></script>
<script>
  $(function () {
    // Summernote
    $('.textarea').summernote({height:320})
    $('.textarea').summernote('code',"<?php echo e(old('content')); ?>"  )
    <?php if ($errors->has('content')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('content'); ?>
        let editor = $('div.note-editor.note-frame')
        editor.css('border','solid 1px red')
        .before("<?php echo $__env->make('dashboard.partials._errors-form',['errors',$errors,'name'=>'content'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>")
    <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
  })
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/vagrant/gomezsite2020/resources/views/dashboard/blog/articles/create.blade.php ENDPATH**/ ?>