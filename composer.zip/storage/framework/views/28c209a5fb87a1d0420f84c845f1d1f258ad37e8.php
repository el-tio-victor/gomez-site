<?php if($filter == 'all'): ?>
    <strong class='ml-3  badge-tech'> Todos</strong>
<?php elseif($filter == 'category'): ?>
<div class='ml-3'>

    	<strong class="">Categoría</strong>
	<span class='badge-tech'>	<?php echo e($filter_obj['category_name']); ?></span>
</div>
<?php elseif( $filter == 'tag' ): ?>
<div class='ml-3'>
    <strong class=''>Tag</strong>
    <span class="badge-tech">
		<?php echo e($filter_obj['tag_name']); ?>

</span>
</div>
<?php endif; ?> 
<?php /**PATH /home/vagrant/gomezsite2020/resources/views/site/blog/partials/filter.blade.php ENDPATH**/ ?>