

<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('css/bootstrap.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/portfolio.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('header'); ?>
        <?php $__env->startComponent('site.partials._header'); ?>
            <div class='header-intro d-flex flex-column align-items-center justify-content-center'>
                <!--<img class='col-10 col-sm-8 col-md-6 col-lg-5' src="<?php echo e(asset('images/page/code.svg')); ?>" alt="">-->
                <h1 class='text-center'>Echa un vistazo a mis proyectos</h1>
            </div>
        <?php echo $__env->renderComponent(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('title','Portafolio'); ?>

<?php $__env->startSection('content'); ?>
    <section class="mt-5 mb-5  d-flex justify-content-center nav-categories-wrapper">
        <nav class=' nav justify-content-around categories-nav'>
        	<?php if( ! isset($slug) ): ?>
        		<?php $class_active = 'active'; ?>
        	<?php else: ?>
        		<?php $class_active = ''; ?>
        	<?php endif; ?>
            <li class='nav-item '><a href="<?php echo e(route('portfolio')); ?>" class=" nav-link <?php echo e($class_active); ?>">TODOS</a></li>
            <?php $__currentLoopData = $categoriesWork; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            	<?php
            		$class_active = '';
            		if(isset($slug)){
            			if($slug === $cat->categoryWork_slug)
            				$class_active = 'active';
            		}
            		
            	?>
            	<li class='nav-item'> <a href="<?php echo e(route('portafolio.search.work',$cat->categoryWork_slug)); ?>" class=" nav-link <?php echo e($class_active); ?>"><?php echo e($cat->categoryWork_name); ?></a> </li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </nav>
    </section>
    
            
    <?php $__currentLoopData = $works; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $work): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php if( ($loop->index + 1) % 2 != 0): ?>
        <section class=' works-contain container-fluid d-flex flex-column flex-lg-row justify-content-center align-items-start'> 
        <?php endif; ?>
            <?php $__env->startComponent('site.portfolio.partials.work'); ?>
                <?php $__env->slot('title',$work->title); ?>
                <?php $__env->slot('services', $work->services); ?>
                <?php $__env->slot('detail',$work->detail); ?>
                <?php $__env->slot('url', $work->url ); ?>
                <?php $__env->slot('images', $work->images()->where('image_main',1)->get() ); ?>
                <?php $__env->slot('tt', $work->technologyTool); ?>
                <?php $__env->slot('work_slug', $work->slug ); ?>
            <?php echo $__env->renderComponent(); ?>
        <?php if( ($loop->index + 1) % 2 === 0 || $loop->last): ?>
        </section>
        <?php endif; ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<div class=" pb-5 d-flex justify-content-center paginate">
    <?php if( count($works) > 0): ?>
    <?php echo e($works->render()); ?>

    <?php else: ?>
	<?php $__env->startComponent('site.partials._no-results'); ?><?php echo $__env->renderComponent(); ?>
    <?php endif; ?>
</div>

    
            
        
<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer'); ?>
    <?php echo $__env->make('site.partials._footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script>
        var slash_top, slash_bottom, slash_middle, btn_menu,nav_main
        window.onload = function(){
            btn_menu        = document.querySelector('.btn-menu')
            slash_top       = btn_menu.querySelector('.slash-top')
            slash_bottom    = btn_menu.querySelector('.slash-bottom')
            slash_middle    = btn_menu.querySelector('.slash-middle')
            btn_menu.addEventListener('click',showMenu)
            nav_main = document.querySelector('.navbar-main')
            
        }
        window.addEventListener('scroll' ,function(){
            if( window.scrollY > 80 ){
                nav_main.classList.add('scroll-page')
            }
            else{
                nav_main.classList.remove('scroll-page')
            }
        }) 

        function showMenu(){
            btn_menu.classList.toggle('active')
            let cont_menu = document.querySelector('.nav-main-items')
            cont_menu.classList.toggle('active')

            //slash de boton menu
            slash_top.classList.toggle('active')
            slash_bottom.classList.toggle('active')
            slash_middle.classList.toggle('active')
        }
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.site', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/vagrant/gomezsite2020/resources/views/site/portfolio/portfolio.blade.php ENDPATH**/ ?>