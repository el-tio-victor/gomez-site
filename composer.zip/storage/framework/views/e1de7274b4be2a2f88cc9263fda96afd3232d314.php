

<?php $__env->startSection('title-doc',' Artículos'); ?>

<?php $__env->startSection('title'); ?>
    Artículos
<?php $__env->stopSection(); ?>

<?php $__env->startSection('breadcrumb-items'); ?>
    <li class="breadcrumb-item active">Artículos</li>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <?php $__env->startComponent('dashboard.partials.card'); ?>
        <?php $__env->slot('header'); ?> <?php $__env->endSlot(); ?>

        <?php $__env->slot('tools'); ?>
            <div class="   wrapper-search">
                <?php echo Form::open(['route'=>'articles.index','method'=>'GET','class'=>'']); ?>

                <div class='d-flex ' style='border:solid .1rem #e9ecef !important;'>
                   
                    <div class="input-group input-group-sm">
                        <?php echo Form::text('title',null,['class'=>'form-control','placeholder'=>'Busqueda', "aria-describedby"=>"search"]); ?>

                        <span class="input-group-append " id="search"> 
                            <button class="btn btn-flat btn-primary" type='button'> <i class="fas fa-search"> </i></button>  
                        </span>
                    </div>
                </div>
                <?php echo Form::close(); ?>

            </div>
        <?php $__env->endSlot(); ?>

        <?php $__env->slot('body'); ?>
        <?php echo $__env->make('flash::message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <a class='btn btn-sm btn-success' href=" <?php echo e(route('articles.create')); ?> ">
            <span class=""><i class=" pr-1 fas fa-plus-circle"> </i>Nuevo Articulo </span>
        </a>
            <table class="table">
                <thead>
                    <tr>
                        <th>#</th>
                        <th>Titulo</th>
                        <th>Categoria</th>
                        <th>Estado </th>
                        <th>Usuario</th>
                        <th>Acciones</th>
                    </tr>
                </thead>
                <tbody>
                    
                    <?php $__currentLoopData = $articles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $article): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr class=" <?php echo e(($article->status === 'edited' )? 'callout callout-warning' : ''); ?> " >
                            <th scope="row"><?php echo e($loop->iteration); ?></th>
                            <td> <?php echo e($article->title); ?> </td>
                            <td> <?php echo e($article->category->name); ?> </td>
                            <td> <?php echo e(($article->status === 'edited' )? 'En edición' : 'Publicado'); ?> </td>
                            <td> <?php echo e($article->user->name); ?> </td>
                            <td>
                                <div class="btn-group btn-group-sm">
                                    <a href="<?php echo e(route('dashboard.articles.destroy',$article->id )); ?>"
                                    onclick="return confirm('Deseas eliminar este elemento?')"  
                                        class="btn  btn-danger" title='Eliminar'>
                                        <span class="fas fa-trash"></span>
                                    </a>
                                    <a href="<?php echo e(route('articles.edit',$article->id )); ?>"
                                        class="btn  btn-warning" title='editar'>
                                        <span class="fas fa-edit"></span>
                                    </a>
                                </div>  
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        <?php $__env->endSlot(); ?>

        <?php $__env->slot('footer'); ?>
        <?php echo $articles->render(); ?>

        <?php $__env->endSlot(); ?>
    <?php echo $__env->renderComponent(); ?>
    
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script>$('div.alert').not('.alert-important').delay(3000).fadeOut(350);</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/vagrant/gomezsite2020/resources/views/dashboard/blog/articles/index.blade.php ENDPATH**/ ?>