<?xml version="1.0" encoding="UTF-8" standalone="no"?>
<svg
   xmlns:dc="http://purl.org/dc/elements/1.1/"
   xmlns:cc="http://creativecommons.org/ns#"
   xmlns:rdf="http://www.w3.org/1999/02/22-rdf-syntax-ns#"
   xmlns:svg="http://www.w3.org/2000/svg"
   xmlns="http://www.w3.org/2000/svg"
   xmlns:sodipodi="http://sodipodi.sourceforge.net/DTD/sodipodi-0.dtd"
   xmlns:inkscape="http://www.inkscape.org/namespaces/inkscape"
   id="svg4663"
   version="1.1"
   viewBox="0 0 317.49999 211.66667"
   class='bg-img'
   sodipodi:docname="intro.svg"
   inkscape:version="0.92.1 r15371">
  <sodipodi:namedview
     pagecolor="#ffffff"
     bordercolor="#666666"
     borderopacity="1"
     objecttolerance="10"
     gridtolerance="10"
     guidetolerance="10"
     inkscape:pageopacity="0"
     inkscape:pageshadow="2"
     inkscape:window-width="1366"
     inkscape:window-height="709"
     id="namedview29"
     showgrid="false"
     inkscape:zoom="0.57333333"
     inkscape:cx="586.04651"
     inkscape:cy="406.97676"
     inkscape:window-x="0"
     inkscape:window-y="0"
     inkscape:window-maximized="1"
     inkscape:current-layer="layer2" />
  <defs
     id="defs4657" />
  <metadata
     id="metadata4660">
    <rdf:RDF>
      <cc:Work
         rdf:about="">
        <dc:format>image/svg+xml</dc:format>
        <dc:type
           rdf:resource="http://purl.org/dc/dcmitype/StillImage" />
        <dc:title />
      </cc:Work>
    </rdf:RDF>
  </metadata>
  <g
     inkscape:groupmode="layer"
     id="layer2"
     inkscape:label="Layer 1"
     style="display:inline;opacity:0.49340369">
    <g
       transform="translate(-87.569304,-128.75357)"
       id="layer1"
       style="">
      <path
         inkscape:connector-curvature="0"
         id="rect4606"
         class="corchetes"
         d="m 98.984086,188.96814 3.929874,4.11187 -4.257641,4.06921 m -5.16022,0.0179 -3.944919,-4.12763 4.128786,-3.94607"
         style="display:inline;opacity:0.21000001;fill:none;fill-opacity:1;stroke:#00150a;stroke-width:1.78264904;stroke-linejoin:round;stroke-miterlimit:4;stroke-dasharray:none;stroke-opacity:1" />
      <g
         style="display:inline;opacity:0.45"
         transform="matrix(0.09696201,0,0,0.09696201,100.66829,125.29584)"
         id="g4703">
        <path
           inkscape:connector-curvature="0"
           style="fill:none;fill-opacity:1;stroke:#00150a;stroke-width:12.03999996;stroke-linecap:round;stroke-linejoin:round;stroke-miterlimit:4;stroke-dasharray:none;stroke-opacity:1"
           d="m 344,134 h 29 l -6,102 h -17 z"
           id="rect4696"
           class="sign" />
        <circle
           style="fill:none;fill-opacity:1;stroke:#00150a;stroke-width:12.03999996;stroke-linecap:round;stroke-linejoin:round;stroke-miterlimit:4;stroke-dasharray:none;stroke-opacity:1"
           id="path4699"
           cx="358.5"
           cy="271.5"
           r="12.5" />
      </g>
      <g
         transform="matrix(0.26458333,0,0,0.26458333,0.86680154,127.06461)"
         id="g4915"
         class="coment"
         style="display:inline;opacity:0.59600004">
        <path
           inkscape:connector-curvature="0"
           style="opacity:0.29200003;fill:none;stroke:#000000;stroke-width:6.27083349;stroke-linecap:round;stroke-linejoin:miter;stroke-miterlimit:4;stroke-dasharray:none;stroke-opacity:1"
           d="M 928.33333,115 920,140"
           id="path4878" />
        <path
           inkscape:connector-curvature="0"
           style="opacity:0.29200003;fill:none;stroke:#000000;stroke-width:6.27083349;stroke-linecap:round;stroke-linejoin:miter;stroke-miterlimit:4;stroke-dasharray:none;stroke-opacity:1"
           d="m 943.4375,115 -7.29167,25"
           id="path4878-9" />
      </g>
      <rect
         y="193.97423"
         x="192.84816"
         height="13.229167"
         width="13.229167"
         id="rect4932"
         style="display:inline;opacity:0;fill:none;fill-opacity:1;stroke:#2d970c;stroke-width:2.60350013;stroke-linecap:round;stroke-linejoin:round;stroke-miterlimit:4;stroke-dasharray:none;stroke-opacity:1" />
      <rect
         y="206.11504"
         x="131.16835"
         height="14.448876"
         width="16.513002"
         id="rect4951"
         style="display:inline;opacity:0;fill:none;fill-opacity:1;stroke:#2d970c;stroke-width:2.60350013;stroke-linecap:round;stroke-linejoin:round;stroke-miterlimit:4;stroke-dasharray:none;stroke-opacity:1" />
      <rect
         y="206.67798"
         x="152.93547"
         height="14.073582"
         width="15.950059"
         id="rect4953"
         style="display:inline;opacity:0;fill:none;fill-opacity:1;stroke:#2d970c;stroke-width:2.60350013;stroke-linecap:round;stroke-linejoin:round;stroke-miterlimit:4;stroke-dasharray:none;stroke-opacity:1" />
      <path
         inkscape:connector-curvature="0"
         id="path4919"
         class="ampersand"
         d="m 221.64984,227.12219 c -1.32291,2.64583 -2.31465,3.53806 -3.53806,3.53806 -1.22338,0 -2.21514,-0.99175 -2.21514,-2.21514 0,-1.2234 0.88762,-1.88131 0.88762,-1.88131 0,0 2.56778,-1.6819 2.56778,-2.41545 0,-0.73356 -0.59467,-1.32823 -1.32823,-1.32823 -0.73356,0 -1.32824,0.59467 -1.32824,1.32823 0,0.73355 4.1773,6.29196 4.1773,6.29196"
         style="display:inline;opacity:0.29200003;fill:none;fill-opacity:1;stroke:#00150a;stroke-width:1.3335191;stroke-linecap:round;stroke-linejoin:round;stroke-miterlimit:4;stroke-dasharray:none;stroke-opacity:1" />
      <g
         style="display:inline;opacity:0.36000001"
         id="g5102"
         clas="arrow"
         transform="matrix(0.20346667,0,0,0.20346667,49.188421,133.10601)">
        <path
           inkscape:connector-curvature="0"
           style="opacity:1;fill:none;fill-opacity:1;stroke:#000000;stroke-width:7.02203465;stroke-linecap:round;stroke-linejoin:round;stroke-miterlimit:4;stroke-dasharray:none;stroke-opacity:1"
           d="M 513.24858,445.54729 528.01507,459.0362 514,474.37869"
           id="rect5075" />
        <path
           inkscape:connector-curvature="0"
           style="fill:none;stroke:#000000;stroke-width:5.59161997;stroke-linecap:round;stroke-linejoin:miter;stroke-miterlimit:4;stroke-dasharray:none;stroke-opacity:1"
           d="M 498,450 H 476"
           id="path5082" />
        <path
           inkscape:connector-curvature="0"
           style="fill:none;stroke:#000000;stroke-width:5.59161997;stroke-linecap:round;stroke-linejoin:miter;stroke-miterlimit:4;stroke-dasharray:none;stroke-opacity:1"
           d="M 498,470 H 476"
           id="path5082-3" />
      </g>
      <g
         style="display:inline;opacity:0.3"
         transform="matrix(0.11339286,0,0,0.11339286,92.412492,119.19751)"
         id="g4876"
         class="hashtag">
        <path
           inkscape:connector-curvature="0"
           style="fill:none;stroke:#000000;stroke-width:12.03999996;stroke-linecap:round;stroke-linejoin:miter;stroke-miterlimit:4;stroke-dasharray:none;stroke-opacity:1"
           d="m 810,114 -10,86"
           id="path4804" />
        <path
           inkscape:connector-curvature="0"
           style="fill:none;stroke:#000000;stroke-width:12.03999996;stroke-linecap:round;stroke-linejoin:miter;stroke-miterlimit:4;stroke-dasharray:none;stroke-opacity:1"
           d="m 850,122 -10,88"
           id="path4804-2" />
        <path
           inkscape:connector-curvature="0"
           style="fill:none;stroke:#000000;stroke-width:12.03999996;stroke-linecap:round;stroke-linejoin:miter;stroke-miterlimit:4;stroke-dasharray:none;stroke-opacity:1"
           d="M 884,144 H 782"
           id="path4804-2-7" />
        <path
           inkscape:connector-curvature="0"
           style="fill:none;stroke:#000000;stroke-width:12.03999996;stroke-linecap:round;stroke-linejoin:miter;stroke-miterlimit:4;stroke-dasharray:none;stroke-opacity:1"
           d="M 868,176 H 770"
           id="path4804-2-7-0" />
      </g>
      <rect
         y="204.55756"
         x="134.63982"
         height="13.229167"
         width="15.875"
         id="rect4926"
         style="opacity:0;fill:none;fill-opacity:1;stroke:#ff0000;stroke-width:3.18558335;stroke-linecap:round;stroke-linejoin:round;stroke-miterlimit:4;stroke-dasharray:none;stroke-opacity:1" />
      <rect
         y="196.62006"
         x="126.70232"
         height="13.229167"
         width="7.9375"
         id="rect4928"
         style="opacity:0;fill:none;fill-opacity:1;stroke:#00070a;stroke-width:3.18558335;stroke-linecap:round;stroke-linejoin:round;stroke-miterlimit:4;stroke-dasharray:none;stroke-opacity:1" />
      <rect
         y="209.84923"
         x="166.38982"
         height="13.229167"
         width="15.875"
         id="rect4930"
         style="opacity:0;fill:none;fill-opacity:1;stroke:#49970a;stroke-width:2.60350013;stroke-linecap:round;stroke-linejoin:round;stroke-miterlimit:4;stroke-dasharray:none;stroke-opacity:1" />
    </g>
    <g
       style="display:inline"
       transform="translate(-73.713931,-27.908801)"
       id="layer1-3">
      <path
         inkscape:connector-curvature="0"
         id="rect4606-6"
         class="corchetes"
         d="m 98.984086,188.96814 3.929874,4.11187 -4.257641,4.06921 m -5.16022,0.0179 -3.944919,-4.12763 4.128786,-3.94607"
         style="display:inline;opacity:0.21000001;fill:none;fill-opacity:1;stroke:#00150a;stroke-width:1.78264904;stroke-linejoin:round;stroke-miterlimit:4;stroke-dasharray:none;stroke-opacity:1" />
      <g
         style="display:inline;opacity:0.45"
         transform="matrix(0.09696201,0,0,0.09696201,100.66829,125.29584)"
         id="g4703-7">
        <path
           inkscape:connector-curvature="0"
           style="fill:none;fill-opacity:1;stroke:#00150a;stroke-width:12.03999996;stroke-linecap:round;stroke-linejoin:round;stroke-miterlimit:4;stroke-dasharray:none;stroke-opacity:1"
           d="m 344,134 h 29 l -6,102 h -17 z"
           id="rect4696-5"
           class="sign" />
        <circle
           style="fill:none;fill-opacity:1;stroke:#00150a;stroke-width:12.03999996;stroke-linecap:round;stroke-linejoin:round;stroke-miterlimit:4;stroke-dasharray:none;stroke-opacity:1"
           id="path4699-3"
           cx="358.5"
           cy="271.5"
           r="12.5" />
      </g>
      <g
         transform="matrix(0.26458333,0,0,0.26458333,0.86680154,127.06461)"
         id="g4915-5"
         class="coment"
         style="display:inline;opacity:0.59600004">
        <path
           inkscape:connector-curvature="0"
           style="opacity:0.29200003;fill:none;stroke:#000000;stroke-width:6.27083349;stroke-linecap:round;stroke-linejoin:miter;stroke-miterlimit:4;stroke-dasharray:none;stroke-opacity:1"
           d="M 928.33333,115 920,140"
           id="path4878-6" />
        <path
           inkscape:connector-curvature="0"
           style="opacity:0.29200003;fill:none;stroke:#000000;stroke-width:6.27083349;stroke-linecap:round;stroke-linejoin:miter;stroke-miterlimit:4;stroke-dasharray:none;stroke-opacity:1"
           d="m 943.4375,115 -7.29167,25"
           id="path4878-9-2" />
      </g>
      <rect
         y="193.97423"
         x="192.84816"
         height="13.229167"
         width="13.229167"
         id="rect4932-9"
         style="display:inline;opacity:0;fill:none;fill-opacity:1;stroke:#2d970c;stroke-width:2.60350013;stroke-linecap:round;stroke-linejoin:round;stroke-miterlimit:4;stroke-dasharray:none;stroke-opacity:1" />
      <rect
         y="206.11504"
         x="131.16835"
         height="14.448876"
         width="16.513002"
         id="rect4951-1"
         style="display:inline;opacity:0;fill:none;fill-opacity:1;stroke:#2d970c;stroke-width:2.60350013;stroke-linecap:round;stroke-linejoin:round;stroke-miterlimit:4;stroke-dasharray:none;stroke-opacity:1" />
      <rect
         y="206.67798"
         x="152.93547"
         height="14.073582"
         width="15.950059"
         id="rect4953-2"
         style="display:inline;opacity:0;fill:none;fill-opacity:1;stroke:#2d970c;stroke-width:2.60350013;stroke-linecap:round;stroke-linejoin:round;stroke-miterlimit:4;stroke-dasharray:none;stroke-opacity:1" />
      <path
         inkscape:connector-curvature="0"
         id="path4919-7"
         class="ampersand"
         d="m 221.64984,227.12219 c -1.32291,2.64583 -2.31465,3.53806 -3.53806,3.53806 -1.22338,0 -2.21514,-0.99175 -2.21514,-2.21514 0,-1.2234 0.88762,-1.88131 0.88762,-1.88131 0,0 2.56778,-1.6819 2.56778,-2.41545 0,-0.73356 -0.59467,-1.32823 -1.32823,-1.32823 -0.73356,0 -1.32824,0.59467 -1.32824,1.32823 0,0.73355 4.1773,6.29196 4.1773,6.29196"
         style="display:inline;opacity:0.29200003;fill:none;fill-opacity:1;stroke:#00150a;stroke-width:1.3335191;stroke-linecap:round;stroke-linejoin:round;stroke-miterlimit:4;stroke-dasharray:none;stroke-opacity:1" />
      <g
         style="display:inline;opacity:0.36000001"
         id="g5102-0"
         clas="arrow"
         transform="matrix(0.20346667,0,0,0.20346667,49.188421,133.10601)">
        <path
           inkscape:connector-curvature="0"
           style="opacity:1;fill:none;fill-opacity:1;stroke:#000000;stroke-width:7.02203465;stroke-linecap:round;stroke-linejoin:round;stroke-miterlimit:4;stroke-dasharray:none;stroke-opacity:1"
           d="M 513.24858,445.54729 528.01507,459.0362 514,474.37869"
           id="rect5075-9" />
        <path
           inkscape:connector-curvature="0"
           style="fill:none;stroke:#000000;stroke-width:5.59161997;stroke-linecap:round;stroke-linejoin:miter;stroke-miterlimit:4;stroke-dasharray:none;stroke-opacity:1"
           d="M 498,450 H 476"
           id="path5082-36" />
        <path
           inkscape:connector-curvature="0"
           style="fill:none;stroke:#000000;stroke-width:5.59161997;stroke-linecap:round;stroke-linejoin:miter;stroke-miterlimit:4;stroke-dasharray:none;stroke-opacity:1"
           d="M 498,470 H 476"
           id="path5082-3-0" />
      </g>
      <g
         style="display:inline;opacity:0.3"
         transform="matrix(0.11339286,0,0,0.11339286,92.412492,119.19751)"
         id="g4876-6"
         class="hashtag">
        <path
           inkscape:connector-curvature="0"
           style="fill:none;stroke:#000000;stroke-width:12.03999996;stroke-linecap:round;stroke-linejoin:miter;stroke-miterlimit:4;stroke-dasharray:none;stroke-opacity:1"
           d="m 810,114 -10,86"
           id="path4804-26" />
        <path
           inkscape:connector-curvature="0"
           style="fill:none;stroke:#000000;stroke-width:12.03999996;stroke-linecap:round;stroke-linejoin:miter;stroke-miterlimit:4;stroke-dasharray:none;stroke-opacity:1"
           d="m 850,122 -10,88"
           id="path4804-2-1" />
        <path
           inkscape:connector-curvature="0"
           style="fill:none;stroke:#000000;stroke-width:12.03999996;stroke-linecap:round;stroke-linejoin:miter;stroke-miterlimit:4;stroke-dasharray:none;stroke-opacity:1"
           d="M 884,144 H 782"
           id="path4804-2-7-8" />
        <path
           inkscape:connector-curvature="0"
           style="fill:none;stroke:#000000;stroke-width:12.03999996;stroke-linecap:round;stroke-linejoin:miter;stroke-miterlimit:4;stroke-dasharray:none;stroke-opacity:1"
           d="M 868,176 H 770"
           id="path4804-2-7-0-7" />
      </g>
      <rect
         y="204.55756"
         x="134.63982"
         height="13.229167"
         width="15.875"
         id="rect4926-9"
         style="opacity:0;fill:none;fill-opacity:1;stroke:#ff0000;stroke-width:3.18558335;stroke-linecap:round;stroke-linejoin:round;stroke-miterlimit:4;stroke-dasharray:none;stroke-opacity:1" />
      <rect
         y="196.62006"
         x="126.70232"
         height="13.229167"
         width="7.9375"
         id="rect4928-2"
         style="opacity:0;fill:none;fill-opacity:1;stroke:#00070a;stroke-width:3.18558335;stroke-linecap:round;stroke-linejoin:round;stroke-miterlimit:4;stroke-dasharray:none;stroke-opacity:1" />
      <rect
         y="209.84923"
         x="166.38982"
         height="13.229167"
         width="15.875"
         id="rect4930-0"
         style="opacity:0;fill:none;fill-opacity:1;stroke:#49970a;stroke-width:2.60350013;stroke-linecap:round;stroke-linejoin:round;stroke-miterlimit:4;stroke-dasharray:none;stroke-opacity:1" />
    </g>
    <g
       style="display:inline"
       transform="translate(65.330229,-111.9639)"
       id="layer1-2">
      <path
         inkscape:connector-curvature="0"
         id="rect4606-3"
         class="corchetes"
         d="m 98.984086,188.96814 3.929874,4.11187 -4.257641,4.06921 m -5.16022,0.0179 -3.944919,-4.12763 4.128786,-3.94607"
         style="display:inline;opacity:0.21000001;fill:none;fill-opacity:1;stroke:#00150a;stroke-width:1.78264904;stroke-linejoin:round;stroke-miterlimit:4;stroke-dasharray:none;stroke-opacity:1" />
      <g
         style="display:inline;opacity:0.45"
         transform="matrix(0.09696201,0,0,0.09696201,100.66829,125.29584)"
         id="g4703-75">
        <path
           inkscape:connector-curvature="0"
           style="fill:none;fill-opacity:1;stroke:#00150a;stroke-width:12.03999996;stroke-linecap:round;stroke-linejoin:round;stroke-miterlimit:4;stroke-dasharray:none;stroke-opacity:1"
           d="m 344,134 h 29 l -6,102 h -17 z"
           id="rect4696-9"
           class="sign" />
        <circle
           style="fill:none;fill-opacity:1;stroke:#00150a;stroke-width:12.03999996;stroke-linecap:round;stroke-linejoin:round;stroke-miterlimit:4;stroke-dasharray:none;stroke-opacity:1"
           id="path4699-2"
           cx="358.5"
           cy="271.5"
           r="12.5" />
      </g>
      <g
         transform="matrix(0.26458333,0,0,0.26458333,0.86680154,127.06461)"
         id="g4915-2"
         class="coment"
         style="display:inline;opacity:0.59600004">
        <path
           inkscape:connector-curvature="0"
           style="opacity:0.29200003;fill:none;stroke:#000000;stroke-width:6.27083349;stroke-linecap:round;stroke-linejoin:miter;stroke-miterlimit:4;stroke-dasharray:none;stroke-opacity:1"
           d="M 928.33333,115 920,140"
           id="path4878-8" />
        <path
           inkscape:connector-curvature="0"
           style="opacity:0.29200003;fill:none;stroke:#000000;stroke-width:6.27083349;stroke-linecap:round;stroke-linejoin:miter;stroke-miterlimit:4;stroke-dasharray:none;stroke-opacity:1"
           d="m 943.4375,115 -7.29167,25"
           id="path4878-9-9" />
      </g>
      <rect
         y="193.97423"
         x="192.84816"
         height="13.229167"
         width="13.229167"
         id="rect4932-7"
         style="display:inline;opacity:0;fill:none;fill-opacity:1;stroke:#2d970c;stroke-width:2.60350013;stroke-linecap:round;stroke-linejoin:round;stroke-miterlimit:4;stroke-dasharray:none;stroke-opacity:1" />
      <rect
         y="206.11504"
         x="131.16835"
         height="14.448876"
         width="16.513002"
         id="rect4951-3"
         style="display:inline;opacity:0;fill:none;fill-opacity:1;stroke:#2d970c;stroke-width:2.60350013;stroke-linecap:round;stroke-linejoin:round;stroke-miterlimit:4;stroke-dasharray:none;stroke-opacity:1" />
      <rect
         y="206.67798"
         x="152.93547"
         height="14.073582"
         width="15.950059"
         id="rect4953-6"
         style="display:inline;opacity:0;fill:none;fill-opacity:1;stroke:#2d970c;stroke-width:2.60350013;stroke-linecap:round;stroke-linejoin:round;stroke-miterlimit:4;stroke-dasharray:none;stroke-opacity:1" />
      <path
         inkscape:connector-curvature="0"
         id="path4919-1"
         class="ampersand"
         d="m 221.64984,227.12219 c -1.32291,2.64583 -2.31465,3.53806 -3.53806,3.53806 -1.22338,0 -2.21514,-0.99175 -2.21514,-2.21514 0,-1.2234 0.88762,-1.88131 0.88762,-1.88131 0,0 2.56778,-1.6819 2.56778,-2.41545 0,-0.73356 -0.59467,-1.32823 -1.32823,-1.32823 -0.73356,0 -1.32824,0.59467 -1.32824,1.32823 0,0.73355 4.1773,6.29196 4.1773,6.29196"
         style="display:inline;opacity:0.29200003;fill:none;fill-opacity:1;stroke:#00150a;stroke-width:1.3335191;stroke-linecap:round;stroke-linejoin:round;stroke-miterlimit:4;stroke-dasharray:none;stroke-opacity:1" />
      <g
         style="display:inline;opacity:0.36000001"
         id="g5102-2"
         clas="arrow"
         transform="matrix(0.20346667,0,0,0.20346667,49.188421,133.10601)">
        <path
           inkscape:connector-curvature="0"
           style="opacity:1;fill:none;fill-opacity:1;stroke:#000000;stroke-width:7.02203465;stroke-linecap:round;stroke-linejoin:round;stroke-miterlimit:4;stroke-dasharray:none;stroke-opacity:1"
           d="M 513.24858,445.54729 528.01507,459.0362 514,474.37869"
           id="rect5075-93" />
        <path
           inkscape:connector-curvature="0"
           style="fill:none;stroke:#000000;stroke-width:5.59161997;stroke-linecap:round;stroke-linejoin:miter;stroke-miterlimit:4;stroke-dasharray:none;stroke-opacity:1"
           d="M 498,450 H 476"
           id="path5082-1" />
        <path
           inkscape:connector-curvature="0"
           style="fill:none;stroke:#000000;stroke-width:5.59161997;stroke-linecap:round;stroke-linejoin:miter;stroke-miterlimit:4;stroke-dasharray:none;stroke-opacity:1"
           d="M 498,470 H 476"
           id="path5082-3-9" />
      </g>
      <g
         style="display:inline;opacity:0.3"
         transform="matrix(0.11339286,0,0,0.11339286,92.412492,119.19751)"
         id="g4876-4"
         class="hashtag">
        <path
           inkscape:connector-curvature="0"
           style="fill:none;stroke:#000000;stroke-width:12.03999996;stroke-linecap:round;stroke-linejoin:miter;stroke-miterlimit:4;stroke-dasharray:none;stroke-opacity:1"
           d="m 810,114 -10,86"
           id="path4804-7" />
        <path
           inkscape:connector-curvature="0"
           style="fill:none;stroke:#000000;stroke-width:12.03999996;stroke-linecap:round;stroke-linejoin:miter;stroke-miterlimit:4;stroke-dasharray:none;stroke-opacity:1"
           d="m 850,122 -10,88"
           id="path4804-2-8" />
        <path
           inkscape:connector-curvature="0"
           style="fill:none;stroke:#000000;stroke-width:12.03999996;stroke-linecap:round;stroke-linejoin:miter;stroke-miterlimit:4;stroke-dasharray:none;stroke-opacity:1"
           d="M 884,144 H 782"
           id="path4804-2-7-4" />
        <path
           inkscape:connector-curvature="0"
           style="fill:none;stroke:#000000;stroke-width:12.03999996;stroke-linecap:round;stroke-linejoin:miter;stroke-miterlimit:4;stroke-dasharray:none;stroke-opacity:1"
           d="M 868,176 H 770"
           id="path4804-2-7-0-5" />
      </g>
      <rect
         y="204.55756"
         x="134.63982"
         height="13.229167"
         width="15.875"
         id="rect4926-0"
         style="opacity:0;fill:none;fill-opacity:1;stroke:#ff0000;stroke-width:3.18558335;stroke-linecap:round;stroke-linejoin:round;stroke-miterlimit:4;stroke-dasharray:none;stroke-opacity:1" />
      <rect
         y="196.62006"
         x="126.70232"
         height="13.229167"
         width="7.9375"
         id="rect4928-3"
         style="opacity:0;fill:none;fill-opacity:1;stroke:#00070a;stroke-width:3.18558335;stroke-linecap:round;stroke-linejoin:round;stroke-miterlimit:4;stroke-dasharray:none;stroke-opacity:1" />
      <rect
         y="209.84923"
         x="166.38982"
         height="13.229167"
         width="15.875"
         id="rect4930-6"
         style="opacity:0;fill:none;fill-opacity:1;stroke:#49970a;stroke-width:2.60350013;stroke-linecap:round;stroke-linejoin:round;stroke-miterlimit:4;stroke-dasharray:none;stroke-opacity:1" />
    </g>
  </g>
</svg>
<?php /**PATH /home/vagrant/gomezsite2020/resources/views/site/home/partials/_svg-img-intro.blade.php ENDPATH**/ ?>