<?php 
if( ! isset( $class_flex_childs ) ){
    $class ='justify-content-center align-items-center';
}else{
    $class = $class_flex_childs;
}

?>
<header class=' header-main'>
        <?php $__env->startComponent('site.partials._nav-main'); ?>
        <?php echo $__env->renderComponent(); ?>
        <section class="container-fluid  d-flex <?php echo e($class); ?> header-main-wrapper  ">
            <?php echo e($slot); ?>

        </section>
        
</header><?php /**PATH /home/vagrant/gomezsite2020/resources/views/site/partials/_header.blade.php ENDPATH**/ ?>