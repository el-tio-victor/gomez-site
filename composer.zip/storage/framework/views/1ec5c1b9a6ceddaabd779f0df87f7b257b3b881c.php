
<?php $pag_title = 'Proyectos'; ?>

<?php $__env->startSection('title-doc', $pag_title); ?>

<?php $__env->startSection('title'); ?>
    <?php echo e($pag_title); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('breadcrumb-items'); ?>
    <li class="breadcrumb-item active"><?php echo e($pag_title); ?></li>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>
	<?php echo $__env->make('flash::message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php $__env->startComponent('dashboard.partials.card'); ?>
        <?php $__env->slot('header'); ?>
        	<a href=" <?php echo e(route('works.create')); ?> ">
                <span class="btn btn-flat btn-sm btn-success">Nuevo Proyecto</span>
            </a>
        <?php $__env->endSlot(); ?> <?php $__env->slot('tools',''); ?>

        <?php $__env->slot('body'); ?>
        <table class="table">
            <thead>
                <th>#</th>
                <th>Titulo</th>
                <th>Categoría</th>
                <th>Servicios</th>
                <th>Detalle</th>
                <th>Enlace</th>
                <th>...</th>
            </thead>
            <tbody>
                <?php $__currentLoopData = $works; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $work): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                        
                            <th><?php echo e($loop->iteration); ?></th>
                            <td><?php echo e($work->title); ?> </td>
                            <td>
                            	<?php if($work->categoryWork): ?>
                            	<?php echo e($work->categoryWork->categoryWork_name); ?>

                            	<?php else: ?>
                            	<?php echo e('S/lcategoría'); ?> 
                            	<?php endif; ?>
                            </td>
                            <td>
                            	<?php $__currentLoopData = $work->technologyTool; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $techs_tool): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            	<span class='badge badge-info'> 
                            		<?php echo $techs_tool->technology->technology_name.' / ' .$techs_tool->tool->tool_name; ?>

                            	</span>
                            	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </td>
                            <td><?php echo $work->detail; ?></td>
                            <td>
                            <?php echo e($work->url); ?>

                            </td>
                            <td>
                                <div class="btn-group">
                                    <a class='btn pt-0 pl-1 pr-1 pb-0 btn-danger' href=" <?php echo e(route('works.destroy',$work->id)); ?>" 
                                    onclick="return confirm('Deseas eliminar este elemento?')" >
                                        <i class="fas fa-trash"></i>
                                    </a>
                                    <a class='btn pt-0 pl-1 pr-1 pb-0 btn-warning' href="<?php echo e(route('works.edit',$work->id)); ?>">
                                        
                                        <i class="fas fa-edit"></i>
                                            
                                    </a>
                                </div>
                                
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
        <?php $__env->endSlot(); ?>
        <?php $__env->slot('footer'); ?>
        <?php echo $works->render(); ?>

        <?php $__env->endSlot(); ?>
        <?php echo $__env->renderComponent(); ?>
    
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<script>$('div.alert').not('.alert-important').delay(3000).fadeOut(350);</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/vagrant/gomezsite2020/resources/views/dashboard/works/work/index.blade.php ENDPATH**/ ?>