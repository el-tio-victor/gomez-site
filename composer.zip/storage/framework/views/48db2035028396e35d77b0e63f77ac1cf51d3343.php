

<?php $__env->startSection('title-doc','Editar  Artículo'); ?>

<?php $__env->startSection('title'); ?>
    Editar artículo
<?php $__env->stopSection(); ?>

<?php $__env->startSection('breadcrumb-items'); ?>
    <li class="breadcrumb-item "><a href="dashboard.articles" class="">Artículos</a></li>
    <li class="breadcrumb-item active">Editar</li>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('dashboard.blog.articles._form',['route'=>['articles.update',$article], 'article'=> $article,'method' => 'PUT'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>





<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/vagrant/gomezsite2020/resources/views/dashboard/blog/articles/edit.blade.php ENDPATH**/ ?>