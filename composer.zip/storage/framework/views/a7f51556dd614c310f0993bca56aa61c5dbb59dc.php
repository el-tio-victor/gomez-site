<table class="table">
    <thead>
        <tr>
            <th>#</th>
            <th>Nombre</th>
            <th>...</th></tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $categoriesWork; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($loop->index +1); ?></td>
                <td> <?php echo e($category->categoryWork_name); ?> </td>
                <td>
                    <div class="btn-group">
                        <a href="<?php echo e(route('categoriesWork.destroy',$category->id)); ?>"  class=" btn btn-danger p-0 pl-1 pr-1"
                        	onclick="return confirm('Deseas eliminar este elemento?')"  >
                        	<i class="fas fa-trash"></i>
                        
                        </a>
                        
                        <a href="" data-id_catego="<?php echo e($category->id); ?>" data-catego_name='<?php echo e($category->categoryWork_name); ?>' class="btn btn-warning p-0 btn-edit" data-action='edit'><i class="fas fa-edit"></i></a>
                    </div>
                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table><?php /**PATH /home/vagrant/gomezsite2020/resources/views/dashboard/works/categoriesWork/partials/_catego-body.blade.php ENDPATH**/ ?>