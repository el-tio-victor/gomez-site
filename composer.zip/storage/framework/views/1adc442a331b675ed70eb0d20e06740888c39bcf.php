

<?php $__env->startSection('header'); ?>
        <?php $__env->startComponent('site.partials._header'); ?>
            <div class='header-intro'>
                <img src="<?php echo e(asset('images/page/code.svg')); ?>" alt="">
                <h1>Mis Proyectos</h1>
            </div>
        <?php echo $__env->renderComponent(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.site', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/vagrant/gomezsite2020/resources/views/site/portfolio/main.blade.php ENDPATH**/ ?>