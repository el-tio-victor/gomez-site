

<?php $__env->startSection('title','Blog'); ?>

<?php $__env->startSection('css'); ?>
        <link rel="stylesheet" href="<?php echo e(asset('css/bootstrap.css')); ?>">
        <link rel="stylesheet" href="<?php echo e(asset('css/blog.css')); ?>">
        <style>
            .collapse{
                display:none;
            }
            .collapse.show{
                display:block;
            }
        </style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('header'); ?>
        <?php $__env->startComponent('site.partials._header'); ?>
            <div class='header-intro'>
                <h1>Algunas notas</h1>
            </div>
        <?php echo $__env->renderComponent(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('site.blog.partials.nav-blog', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <section class="container mt-2  d-flex flex-column align-items-baseline">
        <h1 class='m-0'>Artículos</h1>
            <?php $__env->startComponent('site.blog.partials.filter'); ?>
                <?php $__env->slot('filter',$filter->all()['filter']); ?>
                <?php $__env->slot('filter_obj', $filter->all() ); ?>
            <?php echo $__env->renderComponent(); ?>
        
    </section>
    <section class=" p-1 p-sm-2 p-md-4 p-lg-5 articles">
       
        <?php $__currentLoopData = $articles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $article): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

            <?php if( ($loop->index + 1) % 2 != 0): ?>
            <section class=' container d-flex flex-column flex-lg-row justify-content-around align-items-center mt-3 mb-3'> 
            <?php endif; ?>
            
            <?php if(isset($article->images)): ?>
                <?php $img_name = $article->images[0]->name; ?>
            <?php endif; ?>
            <?php if(!isset($article->images)): ?>
                <?php $img_name = $article->image_name ; ?>
            <?php endif; ?>


                <?php $__env->startComponent('site.blog.partials.article'); ?>
                    <?php $__env->slot('article_slug',$article->slug); ?>
                   
                        <?php $__env->slot( 'image_name',$img_name ); ?>
                    
                    <?php $__env->slot('article_title',$article->title); ?>
                    <?php $__env->slot('category',$article->category->name); ?>
                    <?php $__env->slot('summary',$article->summary); ?>
                    <?php $__env->slot('date',$article->updated_at->diffForHumans()); ?>
                <?php echo $__env->renderComponent(); ?>

            <?php if( ($loop->index + 1) % 2 === 0 || $loop->last): ?>
                </section>
            <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	<?php if( count($articles) === 0): ?>
		<div class='d-flex justify-content-center align-items-center'>
		<?php $__env->startComponent('site.partials._no-results'); ?><?php echo $__env->renderComponent(); ?>
		</div>
	<?php endif; ?>
        <section class=" d-flex justify-content-center articles-paginate">
        <?php echo e($articles->links()); ?>

    </section>
    </section>
    

<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer'); ?>
    <?php echo $__env->make('site.partials._footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" ></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" ></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" ></script>
    <script>
        var slash_top, slash_bottom, slash_middle, btn_menu,nav_main

        $(document).ready(function(){
            /**Variables menu burger */
            btn_menu        = document.querySelector('.btn-menu')
            slash_top       = btn_menu.querySelector('.slash-top')
            slash_bottom    = btn_menu.querySelector('.slash-bottom')
            slash_middle    = btn_menu.querySelector('.slash-middle')
            btn_menu.addEventListener('click',showMenu)
            nav_main = document.querySelector('.navbar-main')

            $('.link-sub-blog').click(function(){
                let el = $(this)
                let attr_href = el.attr('href')

                el.toggleClass('active')
                let links_sub_not = $('.link-sub-blog.active'+":not(a[href='"+attr_href+"'])")
                console.log(links_sub_not)
                links_sub_not.each(function(){
                    $(this).toggleClass('active')
                })
                //busco los contenedores del collapse que estan visibles y que no corresponden 
                //al clickeado y los oculto
                let collapses = $('.collapse.show'+':not('+attr_href+')')
                
                collapses.each(function(){
                    $(this).toggleClass('show')
                })
            })

            window.addEventListener('scroll' ,function(){
                if( window.scrollY > 80 ){
                    nav_main.classList.add('scroll-page')
                }
                else{
                    nav_main.classList.remove('scroll-page')
                }
            }) 

            function showMenu(){
                btn_menu.classList.toggle('active')
                let cont_menu = document.querySelector('.nav-main-items')
                cont_menu.classList.toggle('active')

                //slash de boton menu
                slash_top.classList.toggle('active')
                slash_bottom.classList.toggle('active')
                slash_middle.classList.toggle('active')
            }
        })
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.site', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/vagrant/gomezsite2020/resources/views/site/blog/blog.blade.php ENDPATH**/ ?>