<!-- Left navbar links -->
<ul class="navbar-nav">
      <li class="nav-item">
        <a class="nav-link" data-widget="pushmenu" href="<?php echo e(route('home')); ?>" role="button"><i class="fas fa-bars"></i></a>
      </li>
      <li class="nav-item d-none d-sm-inline-block">
        <a href="<?php echo e(route('home')); ?>" class="nav-link">Home</a>
      </li>
      <li class="nav-item d-none d-sm-inline-block">
        <a href="<?php echo e(route('portfolio')); ?>" class="nav-link">Proyectos</a>
      </li>
      <li class="nav-item d-none d-sm-inline-block">
        <a href="<?php echo e(route('blog')); ?>" class="nav-link">blog</a>
      </li>
      <li class="nav-item d-none d-sm-inline-block">
        <a href="<?php echo e(route('logout')); ?>" class="nav-link">logout</a>
      </li>
</ul><?php /**PATH /home/vagrant/gomezsite2020/resources/views/dashboard/partials/nav/_navbar-left.blade.php ENDPATH**/ ?>