<div class="col-12 col-sm-8 col-md-3 work-techs ">
    <h3>Tecnologías</h3>
    <ul>
    <?php $__currentLoopData = $work_techs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tech): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	<?php
		$tool_name = $tech->tool->tool_name;
		$tool_name = ($tool_name === "N/A") ? '' : $tool_name ;
	?> 
	<li>
		<strong class=' badge badge-pill bg-naranja'>
		<?php echo e($tech->technology->technology_name); ?>&nbsp;/&nbsp;<?php echo e($tool_name); ?>

		</strong>
	</li>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
</div>
<?php /**PATH /home/vagrant/gomezsite2020/resources/views/site/portfolio/partials/_work_techs.blade.php ENDPATH**/ ?>