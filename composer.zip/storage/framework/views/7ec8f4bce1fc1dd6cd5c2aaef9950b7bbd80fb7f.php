

<?php $__env->startSection('css'); ?>
        <!--<link rel="stylesheet" href="<?php echo e(asset('css/bootstrap.css')); ?>">-->
        <link rel="stylesheet" href="<?php echo e(asset('css/main.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('header'); ?>
        <?php $__env->startComponent('site.partials._header'); ?>
            <div class='header-intro'>
                <h1>Gomez-Site</h1>
                <h2 class=' d-flex flex-column'>
                    <div class='text-right'><span>by</span> víctor gómez</div>
                    <div class=" pr-3 text-right social">
                        <i class='icon-linkedin'></i>
                        <i class='mr-1 ml-2 icon-codepen'></i>
                        <i class='icon-github'></i>
                        <i class="icon-facebook"></i>
                    </div>
                </h2>
                
            </div>
        <?php echo $__env->renderComponent(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <section class="about">
        <div class=" container about-me">
            
            <div class='d-flex justify-content-center flex-column-reverse flex-md-row align-items-center'>
            	<div class='col-12 col-md-6 col-lg-5 mb-5 align-self-end '>
                	<h2 class='subt'>¿Qué cosa es víctor?</h2>
                    <p class='about-me-text '>
                        Mi nombre es Víctor Manuel. Desarrollador web, apacionado por todo el impacto visual que un buen diseño puede ocacionar. Creyente
                        de que las cosas bien hechas son las mejores
                    </p>
            	</div>
            	
                <img class=' col-7  col-md-5' src="<?php echo e(asset('/images/page/avatar.svg')); ?>" alt="">
            </div>
            
        </div>
        <div class="about-skills  mb-5 container">
               <h2 class='mt-5 mb-5 subt'>Y sus habilidades...</h2>
                <div class="margin-top-bott-elem skills-wrapper">
                    <div class="d-flex flex-column flex-sm-row  justify-content-around skills1">
                        <div class=' d-flex justify-content-center align-items-center skill'>
                            <h3>HTML</h3>
                        </div>
                        <div class='  d-flex justify-content-center align-items-center  skill'>
                            <h3>CSS</h3>
                        </div>
                        <div class=' d-flex justify-content-center align-items-center skill'>
                            <h3>JAVASCRIPT</h3>
                        </div>
                    </div>
                    <div class="d-flex d-flex flex-column flex-sm-row  justify-content-around  skills2">
                        <div class='d-flex justify-content-center align-items-center skill'>
                            <h3>PHP</h3>
                        </div>
                        <div class=' d-flex justify-content-center align-items-center skill'>
                            <h3>SQL</h3>
                        </div>
                        <div class='col-12 col-sm-4 d-flex justify-content-center align-items-center skill'>
                            
                        </div>
                    </div>
                </div>
        </div>
        <div class="mt-5  d-flex align-items-center justify-content-center">
        	<div class=" d-flex align-items-center justify-content-center btn-flat">
        		<span class='btn-text'>VER CV</span>
        	</div>
            
        </div>
        <div class="container  about-footer">            
        </div>
    </section>
    <section class='works'>
        <header class=" container  works-header">
            <h2 class='mt-5 mb-5 subt'>Últimos proyectos</h2>
            <div class="margin-top-bott-elem d-flex  flex-column flex-md-row justify-content-center align-items-center works-intro">
                <div class='col-md-4'><img class='col-12' src="<?php echo e(asset('/images/page/code.svg')); ?>" alt=""> </div>
                <div class='col-8 col-sm-4 mt-3 mt-md-0 ml-md-5'><p>Estos son algunos de mis proyectos desarrollados.</p></div>
            </div>
        </header>
        <section class='works-contain container-fluid d-flex flex-column flex-lg-row justify-content-center align-items-center'>
            <?php echo $__env->make('site.home.partials.contentWorks', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </section>
        <div class="mt-5 mb-5 d-flex align-items-center justify-content-center">
            <a href="<?php echo e(route('portfolio')); ?>">
                <div class=" d-flex align-items-center justify-content-center btn-flat">
                    <span class='btn-text'>VER PORTAFOLIO</span>
                </div>
            </a>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer'); ?>
    <?php echo $__env->make('site.partials._footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script>
        var slash_top, slash_bottom, slash_middle, btn_menu,nav_main
        
        window.onload = function(){
            btn_menu        = document.querySelector('.btn-menu')
            slash_top       = btn_menu.querySelector('.slash-top')
            slash_bottom    = btn_menu.querySelector('.slash-bottom')
            slash_middle    = btn_menu.querySelector('.slash-middle')
            btn_menu.addEventListener('click',showMenu)
            nav_main = document.querySelector('.navbar-main')
            
        }
        window.addEventListener('scroll' ,function(){
            if( window.scrollY > 80 ){
                nav_main.classList.add('scroll-page')
            }
            else{
                nav_main.classList.remove('scroll-page')
            }
        }) 

        function showMenu(){
            btn_menu.classList.toggle('active')
            let cont_menu = document.querySelector('.nav-main-items')
            cont_menu.classList.toggle('active')

            //slash de boton menu
            slash_top.classList.toggle('active')
            slash_bottom.classList.toggle('active')
            slash_middle.classList.toggle('active')
        }
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.site', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/victor/desarrollo/gomezsite2020/resources/views/site/home/home.blade.php ENDPATH**/ ?>