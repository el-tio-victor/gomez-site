

<?php $__env->startSection('title-doc','Imágenes'); ?>

<?php $__env->startSection('title'); ?>
    Imágenes
<?php $__env->stopSection(); ?>

<?php $__env->startSection('breadcrumb-items'); ?>
    <li class="breadcrumb-item active">Imágenes generales</li>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
  <section class="d-flex">
    <div class="info-box">
    <span class="info-box-icon bg-info"><i class="far fa-envelope"></i></span>
    <div class="info-box-content">
      <span>Sube tú imágen</span>
      <?php echo Form::open(['route'=>'images.store','method'=>'POST','files'=>'true']); ?>

          <?php echo Form::file('image'); ?>

          <?php echo Form::submit('Subir'); ?>

      <?php echo Form::close(); ?>

    </div>
    </div>
  </section>

    
  <?php $__env->startComponent('dashboard.partials.card', ['class_card'=>'card-outline card-primary']); ?>
      <?php $__env->slot('header','Todas las categorias'); ?><?php $__env->slot('tools',''); ?>
      <?php $__env->slot('body'); ?>
          <?php if($imgs['status']): ?>
              <?php $__currentLoopData = $imgs['imgs']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $img): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="card" style="width: 18rem;">
                      <img class="card-img-top" src="/images/articles/generals/<?php echo e($img); ?>" alt="">
                      <div class="card-body">
                        <h5 class="card-title">Enlace</h5>
                        <small class="card-text">/images/articles/generals/<?php echo e($img); ?></small>
                        <a href="#" class="btn btn-primary">Go somewhere</a>
                      </div>
                </div>
                  <img src="" alt="">
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          <?php else: ?>
            <p>No  se han cargado imágenes aun</p>
          <?php endif; ?>
      <?php $__env->endSlot(); ?>
      <?php $__env->slot('footer',''); ?>
  <?php echo $__env->renderComponent(); ?>
  
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/vagrant/gomezsite2020/resources/views/dashboard/blog/images/indexGenerals.blade.php ENDPATH**/ ?>