

<?php $__env->startSection('title-doc',' Categorías'); ?>

<?php $__env->startSection('title'); ?>
    Categorías
<?php $__env->stopSection(); ?>

<?php $__env->startSection('breadcrumb-items'); ?>
    <li class="breadcrumb-item active">Categorías</li>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>
<?php echo $__env->make('flash::message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="row">
        <section class='col-md-6 col-lg-7 '>
            <?php $__env->startComponent('dashboard.partials.card', ['class_card'=>'card-outline card-primary']); ?>
                <?php $__env->slot('header','Todas las categorias'); ?><?php $__env->slot('tools',''); ?>
                <?php $__env->slot('body'); ?>
                    <a href=" <?php echo e(route('categories.index')); ?> " class='btn btn-sm btn-success'><i class="fas fa-plus pr-1"></i> Agregar Categoria</a>
                    
                        <table class="table">
                            <thead>
                                <tr>
                                    <th scope="col">#</th>
                                    <th scope="col">Nombre</th>
                                    <th scope="col">Acciones</th>             
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <th scope="row"><?php echo e($loop->iteration); ?></th>
                                        <td><?php echo e($category->name); ?></td> 
                                        <td>
                                            <div class="btn-group btn-sm">
                                                <a class='pl-1 pr-1 pt-0 pb-0 btn btn-danger' role='button'
                                                    onclick="return confirm('Deseas eliminar este elemento?')" 
                                                 href=" <?php echo e(route('dashboard.categories.destroy',$category->id)); ?> "> 
                                                    <i class="fas fa-trash"></i>
                                                </a>
                                                <a class=' pl-1 pr-1 pt-0 pb-0 btn btn-warning' href=" <?php echo e(route('categories.edit',$category->id)); ?> ">
                                                    <i class="fas fa-edit"></i>
                                                </a>
                                            </div-btn-group>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                        <nav aria-label="Page navigation">
                           
                        </nav>
                        
                    
                <?php $__env->endSlot(); ?>
                <?php $__env->slot('footer'); ?>
                <?php echo $categories->render(); ?>

                <?php $__env->endSlot(); ?>
            <?php echo $__env->renderComponent(); ?>
        </section>
        <section class='col-md-6 col-lg-5 '>
            <div>
                <?php $__env->startComponent('dashboard.partials.card', ['class_card'=>'card-outline card-success']); ?>
                    <?php $__env->slot('header','Nueva Categoría'); ?><?php $__env->slot('tools',''); ?>
                    <?php $__env->slot('body'); ?>
                        <?php if($category_edit === null): ?>
                            <?php echo $__env->make('dashboard.blog.categories._form',['route'=>'categories.store','method'=>'POST'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        <?php endif; ?>
                    <?php $__env->endSlot(); ?>
                    <?php $__env->slot('footer',''); ?>
                <?php echo $__env->renderComponent(); ?>
            </div>
            <div>
                <?php $__env->startComponent('dashboard.partials.card', ['class_card'=>'card-outline card-warning']); ?>
                    <?php $__env->slot('header','Editar categoría'); ?><?php $__env->slot('tools',''); ?>
                    <?php $__env->slot('body'); ?>
                        <?php if($category_edit != null): ?>
                            <?php echo $__env->make('dashboard.blog.categories._form',['route'=>['categories.update',$category],'method'=>'PUT'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        <?php endif; ?>   
                    <?php $__env->endSlot(); ?>
                    <?php $__env->slot('footer',''); ?>
                <?php echo $__env->renderComponent(); ?>
            </div>
        </section>
    </div>
    
    
    
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script>$('div.alert').not('.alert-important').delay(3000).fadeOut(350);</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/vagrant/gomezsite2020/resources/views/dashboard/blog/categories/index.blade.php ENDPATH**/ ?>