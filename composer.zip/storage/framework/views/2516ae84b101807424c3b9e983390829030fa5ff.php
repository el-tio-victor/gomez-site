
    <div class="">
        <?php echo Form::open( ['route'=>'categories.store','method'=>'POST'] ); ?>

        <?php echo Form::label("name","Nombre ",['class'=>'col ']); ?>

            <div class="col d-flex form-group">
            
                <?php echo Form::text("name",null,['class'=>'form-control', 'placeholder'=>"Nombre Categoría",'required'=>'required']); ?>

                <?php if( count($errors->get('name'))> 0 ): ?>
                    <span class="msg alert-danger">
                        <?php $__currentLoopData = $errors->get('name'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                                <?php echo e($message); ?> 
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </span>
                <?php endif; ?>
            </div>
            <div class="col form-group">
            <?php echo Form::submit('Guardar',['class'=>'btn btn-sm btn-success']); ?>

            </div>
        <?php echo Form::close(); ?>

    </div>
    

<?php /**PATH /home/vagrant/gomezsite2020/resources/views/dashboard/blog/categories/create.blade.php ENDPATH**/ ?>