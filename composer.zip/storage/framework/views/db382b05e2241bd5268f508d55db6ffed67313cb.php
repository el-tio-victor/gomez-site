<div class='d-flex align-items-center justify-content-center btn-flat'>
    <span class='btn-text'>
       <?php echo e($text_link); ?> 
    </span>
</div>
<?php /**PATH /home/vagrant/gomezsite2020/resources/views/dashboard/partials/_btn-flat.blade.php ENDPATH**/ ?>