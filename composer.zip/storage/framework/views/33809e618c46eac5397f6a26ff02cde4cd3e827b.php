<footer class='text-center p-1 footer-main'>
    <span>Derechos reservados</span>
</footer><?php /**PATH /home/vagrant/gomezsite2020/resources/views/site/partials/_footer.blade.php ENDPATH**/ ?>