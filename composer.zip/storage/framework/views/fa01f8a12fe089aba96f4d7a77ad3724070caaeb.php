<nav class="d-flex mt-5  justify-content-center <?php echo e(Request::is('blog/*')? 'pt-5' : ''); ?>">
    <ul class="nav categories-nav">
        <li class="nav-item mr-3">
            <a class="nav-link dropdown-toggle link-sub-blog" data-toggle="collapse" href="#categoriesCollapse" role="button" aria-expanded="false" aria-controls="categoriesCollapse">CATEGORÍAS</a>
        </li>
        <li class="nav-item">
            <a class="nav-link dropdown-toggle link-sub-blog" data-toggle="collapse" href="#tagsCollapse" role="button" aria-expanded="false" aria-controls="tagsCollapse">TAGS</a>
        </li>
    </ul>
</nav>
<div class="collapse" id="categoriesCollapse">
    <div class="mt-3 d-flex justify-content-center">
        <div class="border p-4 col-11 col-sm-10">
            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <a href="<?php echo e(route( 'blog.search.category',$category->category_slug )); ?>">
                    <span class='badge badge-pill badge-orange'>
                        <?php echo e($category->name); ?>&nbsp; <small class='badge badge-light'><?php echo e($category->articles->count()); ?></small> 
                    </span>
                </a>     
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
</div>
<div class=" collapse" id="tagsCollapse">
    <div class="mt-3 d-flex justify-content-center">
        <div class="border p-4 col-11 col-sm-10">
            <?php $__currentLoopData = $tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <a href=" <?php echo e(route( 'blog.search.tag',$tag->tag_slug )); ?> ">
                    <span class='badge badge-pill badge-info'> <?php echo e($tag->name); ?> </span>
                </a>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
</div>


<?php /**PATH /home/vagrant/gomezsite2020/resources/views/site/blog/partials/nav-blog.blade.php ENDPATH**/ ?>