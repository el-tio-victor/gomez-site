
<!-- Created with Inkscape (http://www.inkscape.org/) -->

<svg
   xmlns:osb="http://www.openswatchbook.org/uri/2009/osb"
   xmlns:dc="http://purl.org/dc/elements/1.1/"
   xmlns:cc="http://creativecommons.org/ns#"
   xmlns:rdf="http://www.w3.org/1999/02/22-rdf-syntax-ns#"
   xmlns:svg="http://www.w3.org/2000/svg"
   xmlns="http://www.w3.org/2000/svg"
   xmlns:xlink="http://www.w3.org/1999/xlink"
   xmlns:sodipodi="http://sodipodi.sourceforge.net/DTD/sodipodi-0.dtd"
   xmlns:inkscape="http://www.inkscape.org/namespaces/inkscape"
   width="100%"
   height="auto"
   viewBox="0 0 119.0625 198.4375"
   version="1.1"
   id="svg8"
   inkscape:version="0.92.5 (2060ec1f9f, 2020-04-08)"
   sodipodi:docname="phantom.svg">
  <defs
     id="defs2">
    <linearGradient
       id="linearGradient937"
       osb:paint="solid">
      <stop
         style="stop-color:#ffffff;stop-opacity:1;"
         offset="0"
         id="stop935" />
    </linearGradient>
    <linearGradient
       id="linearGradient931"
       osb:paint="solid">
      <stop
         style="stop-color:#ffffff;stop-opacity:1;"
         offset="0"
         id="stop929" />
    </linearGradient>
    <linearGradient
       id="linearGradient925"
       osb:paint="solid">
      <stop
         style="stop-color:#ffffff;stop-opacity:1;"
         offset="0"
         id="stop923" />
    </linearGradient>
    <linearGradient
       id="linearGradient919"
       osb:paint="solid">
      <stop
         style="stop-color:#000000;stop-opacity:1;"
         offset="0"
         id="stop917" />
    </linearGradient>
    <linearGradient
       id="linearGradient913"
       osb:paint="solid">
      <stop
         style="stop-color:#ea5106;stop-opacity:1;"
         offset="0"
         id="stop911" />
    </linearGradient>
    <linearGradient
       id="linearGradient880"
       osb:paint="solid">
      <stop
         style="stop-color:#000000;stop-opacity:1;"
         offset="0"
         id="stop878" />
    </linearGradient>
    <linearGradient
       inkscape:collect="always"
       xlink:href="#linearGradient913"
       id="linearGradient915"
       x1="43.066299"
       y1="102.51585"
       x2="43.067009"
       y2="102.51585"
       gradientUnits="userSpaceOnUse"
       gradientTransform="translate(-21.306386,78.311927)" />
  </defs>
  <sodipodi:namedview
     id="base"
     pagecolor="#ffffff"
     bordercolor="#666666"
     borderopacity="1.0"
     inkscape:pageopacity="0.0"
     inkscape:pageshadow="2"
     inkscape:zoom="0.7"
     inkscape:cx="321.23857"
     inkscape:cy="369.26155"
     inkscape:document-units="px"
     inkscape:current-layer="layer1"
     showgrid="false"
     units="px"
     inkscape:window-width="1366"
     inkscape:window-height="705"
     inkscape:window-x="-8"
     inkscape:window-y="-8"
     inkscape:window-maximized="1">
    <inkscape:grid
       type="xygrid"
       id="grid945" />
  </sodipodi:namedview>
  <metadata
     id="metadata5">
    <rdf:RDF>
      <cc:Work
         rdf:about="">
        <dc:format>image/svg+xml</dc:format>
        <dc:type
           rdf:resource="http://purl.org/dc/dcmitype/StillImage" />
        <dc:title></dc:title>
      </cc:Work>
    </rdf:RDF>
  </metadata>
  <g 
     inkscape:label="Capa 1"
     inkscape:groupmode="layer"
     id="layer1" class='no-results-phanto '
     transform="translate(0,-98.562476)">
    <g
       id="g4786"
       transform="matrix(0.69264242,0,0,0.69264242,35.259152,86.259968)">
      <g
         id="g4775">
        <g
           id="g4765" class='no-results-phantom'
           transform="translate(5.3453906,-9.6217031)">
          <path
             sodipodi:open="true"
             d="m 21.760625,180.85906 a 24.02998,28.726191 0 0 1 -7.12e-4,-0.0626"
             sodipodi:end="3.1290855"
             sodipodi:start="3.1269068"
             sodipodi:ry="28.726191"
             sodipodi:rx="24.02998"
             sodipodi:cy="180.43721"
             sodipodi:cx="45.788013"
             sodipodi:type="arc"
             id="path815"
             style="opacity:1;fill:url(#linearGradient915);fill-opacity:1;stroke:none;stroke-width:2.26499987;stroke-miterlimit:4;stroke-dasharray:none;stroke-dashoffset:24;stroke-opacity:1" />
          <path
             sodipodi:nodetypes="cscssccssccsassc"
             inkscape:connector-curvature="0"
             id="rect849"
             d="m 52.213616,141.12769 h 1.511898 c 17.170702,0 26.55249,12.26415 30.99405,30.99405 1.4828,8.75722 2.82474,17.58172 4.06116,26.3247 0.62903,4.448 22.208026,0.38483 21.454126,15.53289 -1.05884,21.27539 -28.557584,16.91988 -9.30308,49.42366 24.89995,34.5491 -0.30241,41.95587 -7.193726,35.85061 -3.77141,-3.34123 -20.31797,-20.4191 -22.850302,-16.34745 -3.21944,5.17643 -1.733716,20.75768 -14.264858,12.41357 C 36.921937,278.95087 45.88253,294.94998 33.549518,295.15334 24.518344,295.02024 6.850634,269.87129 9.263573,243.51329 9.3188199,234.80496 7.984689,236.65101 3.49769,229.32063 -2.455555,219.59487 -4.6446971,211.44326 0.13493517,204.66362 3.0320212,200.55426 14.561394,203.53594 14.896337,201.56195 c 1.743788,-10.27687 3.911156,-20.37599 6.323228,-29.44021 3.808428,-16.33129 13.823345,-30.99405 30.994051,-30.99405 z"
             style="opacity:1;fill:#ffffff;fill-opacity:1;stroke:#130a06;stroke-width:2.68501639;stroke-miterlimit:4;stroke-dasharray:none;stroke-dashoffset:24;stroke-opacity:1" />
          <path
             d="m 31.610283,174.22859 a 4.6772165,8.2853556 0 0 1 4.617287,-8.3875 4.6772165,8.2853556 0 0 1 4.736387,8.17645 4.6772165,8.2853556 0 0 1 -4.614186,8.39285 4.6772165,8.2853556 0 0 1 -4.739408,-8.17095"
             sodipodi:open="true"
             sodipodi:end="3.1278744"
             sodipodi:start="3.1291834"
             sodipodi:ry="8.2853556"
             sodipodi:rx="4.6772165"
             sodipodi:cy="174.12578"
             sodipodi:cx="36.28714"
             sodipodi:type="arc"
             id="path852"
             style="opacity:1;fill:#000000;fill-opacity:1;stroke:none;stroke-width:2.26499987;stroke-miterlimit:4;stroke-dasharray:none;stroke-dashoffset:24;stroke-opacity:1" />
          <path
             d="m 47.485284,174.22859 a 5.7462945,12.294398 0 0 1 5.672667,-12.44596 5.7462945,12.294398 0 0 1 5.818989,12.1328 5.7462945,12.294398 0 0 1 -5.668857,12.4539 5.7462945,12.294398 0 0 1 -5.8227,-12.12464"
             sodipodi:open="true"
             sodipodi:end="3.1278744"
             sodipodi:start="3.1291834"
             sodipodi:ry="12.294398"
             sodipodi:rx="5.7462945"
             sodipodi:cy="174.07603"
             sodipodi:cx="53.231136"
             sodipodi:type="arc"
             id="path852-6"
             style="opacity:1;fill:#000000;fill-opacity:1;stroke:none;stroke-width:3.05820394;stroke-miterlimit:4;stroke-dasharray:none;stroke-dashoffset:24;stroke-opacity:1" />
          <path
             sodipodi:nodetypes="csszsac"
             inkscape:connector-curvature="0"
             id="path947"
             d="m 26.318614,195.39526 c 0,0 1.474236,-3.96874 3.96875,-3.96874 2.494514,0 3.175129,6.33109 5.669643,6.33109 2.494514,0 3.742093,-3.68526 6.236607,-3.68526 2.494514,0 4.309057,5.19717 6.803571,5.19717 2.494514,0 4.674219,-4.20965 7.370535,-3.68526 2.803902,0.54531 5.669644,6.42559 5.669644,6.42559"
             style="fill:none;stroke:#000000;stroke-width:2.06500006;stroke-linecap:butt;stroke-linejoin:miter;stroke-miterlimit:4;stroke-dasharray:none;stroke-opacity:1" />
          <path
             sodipodi:nodetypes="cc"
             inkscape:connector-curvature="0"
             id="path4749"
             d="m 79.884173,207.2583 c 0,0 -3.194917,34.40773 3.54417,62.94489"
             style="fill:none;stroke:#000000;stroke-width:1.62983334;stroke-linecap:butt;stroke-linejoin:miter;stroke-miterlimit:4;stroke-dasharray:none;stroke-opacity:1" />
          <path
             sodipodi:nodetypes="cc"
             inkscape:connector-curvature="0"
             id="path4751"
             d="m 19.028511,208.56467 c 0,0 -5.853067,20.50895 11.744124,70.91869"
             style="fill:none;stroke:#000000;stroke-width:1.19062495;stroke-linecap:butt;stroke-linejoin:miter;stroke-miterlimit:4;stroke-dasharray:none;stroke-opacity:1" />
        </g>
      </g>
    </g>
    <g
       id="g4884" 
       transform="translate(-1.0583333,-26.987511)">
      <rect
         ry="16.870783"
         y="130.76472"
         x="3.0224781"
         height="41.140358"
         width="73.012962"
         id="rect4794"
         style="opacity:1;fill:#ffffff;fill-opacity:1;fill-rule:nonzero;stroke:#130a06;stroke-width:1.77835679;stroke-miterlimit:4;stroke-dasharray:none;stroke-dashoffset:24;stroke-opacity:1" />
      <g
         transform="translate(-12.170835)"
         id="text4790"
         style="font-style:normal;font-variant:normal;font-weight:normal;font-stretch:normal;font-size:8.46666718px;line-height:1.25;font-family:Roboto;-inkscape-font-specification:Roboto;letter-spacing:0px;word-spacing:0px;fill:#000000;fill-opacity:1;stroke:none;stroke-width:0.26458335"
         aria-label="Sin  resultados">
        <path
           inkscape:connector-curvature="0"
           id="path4817"
           style="font-size:12.69999981px;stroke-width:0.26458335"
           d="m 25.031768,142.82909 q -1.531689,-0.44028 -2.232422,-1.079 -0.694531,-0.64492 -0.694531,-1.5875 0,-1.0666 0.84956,-1.76113 0.855762,-0.70074 2.22002,-0.70074 0.930176,0 1.655713,0.35967 0.731738,0.35967 1.128613,0.99219 0.403076,0.63252 0.403076,1.38286 h -1.196826 q 0,-0.81855 -0.520898,-1.28364 -0.520899,-0.47129 -1.469678,-0.47129 -0.880566,0 -1.37666,0.39067 -0.489893,0.38448 -0.489893,1.07281 0,0.5519 0.465088,0.93637 0.471289,0.37827 1.593701,0.69453 1.128614,0.31626 1.761133,0.70074 0.638721,0.37827 0.942578,0.88676 0.310059,0.5085 0.310059,1.19683 0,1.09761 -0.855762,1.76113 -0.855762,0.65733 -2.288232,0.65733 -0.930176,0 -1.736328,-0.35347 -0.806153,-0.35967 -1.246436,-0.97979 -0.434082,-0.62011 -0.434082,-1.40766 h 1.196826 q 0,0.81855 0.601514,1.29604 0.607715,0.47129 1.618506,0.47129 0.942578,0 1.444873,-0.38447 0.502295,-0.38447 0.502295,-1.048 0,-0.66352 -0.465088,-1.02319 -0.465088,-0.36587 -1.686719,-0.71934 z" />
        <path
           inkscape:connector-curvature="0"
           id="path4819"
           style="font-size:12.69999981px;stroke-width:0.26458335"
           d="m 30.978692,146.85365 h -1.147217 v -6.70966 h 1.147217 z m -1.240234,-8.4894 q 0,-0.27905 0.167431,-0.47129 0.173633,-0.19224 0.508496,-0.19224 0.334864,0 0.508496,0.19224 0.173633,0.19224 0.173633,0.47129 0,0.27905 -0.173633,0.46509 -0.173632,0.18603 -0.508496,0.18603 -0.334863,0 -0.508496,-0.18603 -0.167431,-0.18604 -0.167431,-0.46509 z" />
        <path
           inkscape:connector-curvature="0"
           id="path4821"
           style="font-size:12.69999981px;stroke-width:0.26458335"
           d="m 33.893243,140.14399 0.03721,0.84335 q 0.768945,-0.96738 2.009179,-0.96738 2.127002,0 2.145606,2.39986 v 4.43383 h -1.147217 v -4.44004 q -0.0062,-0.72553 -0.334863,-1.0728 -0.322461,-0.34726 -1.010791,-0.34726 -0.558106,0 -0.979785,0.29765 -0.42168,0.29766 -0.657324,0.78135 v 4.7811 h -1.147217 v -6.70966 z" />
        <path
           inkscape:connector-curvature="0"
           id="path4823"
           style="font-size:12.69999981px;stroke-width:0.26458335"
           d="m 25.434844,157.04838 q -0.260449,-0.0434 -0.564306,-0.0434 -1.128614,0 -1.53169,0.96118 v 4.7625 h -1.147217 v -6.70967 h 1.116211 l 0.0186,0.77515 q 0.564306,-0.89917 1.599902,-0.89917 0.334863,0 0.508496,0.0868 z" />
        <path
           inkscape:connector-curvature="0"
           id="path4825"
           style="font-size:12.69999981px;stroke-width:0.26458335"
           d="m 29.143145,162.85268 q -1.364258,0 -2.22002,-0.89297 -0.855762,-0.89917 -0.855762,-2.39986 v -0.21084 q 0,-0.99838 0.378272,-1.77973 0.384473,-0.78755 1.066601,-1.22783 0.688331,-0.44649 1.488282,-0.44649 1.308447,0 2.033984,0.86196 0.725537,0.86197 0.725537,2.46807 v 0.47749 H 27.21458 q 0.0248,0.99219 0.576709,1.6061 0.558106,0.60772 1.413867,0.60772 0.607715,0 1.029395,-0.24805 0.42168,-0.24804 0.737939,-0.65732 l 0.700733,0.5457 q -0.84336,1.29605 -2.530078,1.29605 z m -0.142627,-6.01514 q -0.694532,0 -1.165821,0.5085 -0.471289,0.50229 -0.58291,1.41386 h 3.361035 v -0.0868 q -0.04961,-0.87437 -0.471289,-1.35186 -0.421679,-0.48369 -1.141015,-0.48369 z" />
        <path
           inkscape:connector-curvature="0"
           id="path4827"
           style="font-size:12.69999981px;stroke-width:0.26458335"
           d="m 36.987627,160.94892 q 0,-0.46509 -0.353467,-0.71934 -0.347265,-0.26045 -1.221631,-0.44648 -0.868164,-0.18604 -1.382861,-0.44649 -0.508496,-0.26045 -0.756543,-0.62012 -0.241846,-0.35966 -0.241846,-0.85576 0,-0.82475 0.694532,-1.39526 0.700732,-0.57051 1.785937,-0.57051 1.141016,0 1.847949,0.58911 0.713135,0.58911 0.713135,1.50689 h -1.153418 q 0,-0.47129 -0.403076,-0.81236 -0.396875,-0.34106 -1.00459,-0.34106 -0.626318,0 -0.979785,0.27285 -0.353467,0.27285 -0.353467,0.71314 0,0.41547 0.328662,0.62631 0.328662,0.21084 1.184424,0.40308 0.861963,0.19224 1.395264,0.45889 0.5333,0.26665 0.787549,0.64492 0.260449,0.37207 0.260449,0.91157 0,0.89917 -0.719336,1.44487 -0.719336,0.53951 -1.866553,0.53951 -0.806152,0 -1.426269,-0.28526 -0.620118,-0.28525 -0.973584,-0.79375 -0.347266,-0.51469 -0.347266,-1.11001 h 1.147217 q 0.03101,0.57671 0.458886,0.91778 0.434083,0.33486 1.141016,0.33486 0.651123,0 1.041797,-0.26045 0.396875,-0.26665 0.396875,-0.70693 z" />
        <path
           inkscape:connector-curvature="0"
           id="path4829"
           style="font-size:12.69999981px;stroke-width:0.26458335"
           d="m 43.771709,162.06513 q -0.669727,0.78755 -1.965772,0.78755 -1.072803,0 -1.637109,-0.62012 -0.558106,-0.62632 -0.564307,-1.84795 v -4.36563 h 1.147217 v 4.33462 q 0,1.52549 1.240234,1.52549 1.314649,0 1.748731,-0.97978 v -4.88033 h 1.147217 v 6.70967 h -1.091407 z" />
        <path
           inkscape:connector-curvature="0"
           id="path4831"
           style="font-size:12.69999981px;stroke-width:0.26458335"
           d="m 47.870684,162.72865 h -1.147217 v -9.525 h 1.147217 z" />
        <path
           inkscape:connector-curvature="0"
           id="path4833"
           style="font-size:12.69999981px;stroke-width:0.26458335"
           d="m 51.256523,154.39428 v 1.6247 h 1.252637 v 0.88677 h -1.252637 v 4.16099 q 0,0.40307 0.167432,0.60771 0.167432,0.19844 0.570508,0.19844 0.198437,0 0.545703,-0.0744 v 0.93017 q -0.452686,0.12403 -0.880566,0.12403 -0.768946,0 -1.159619,-0.46509 -0.390674,-0.46509 -0.390674,-1.32085 v -4.16099 h -1.221631 v -0.88677 h 1.221631 v -1.6247 z" />
        <path
           inkscape:connector-curvature="0"
           id="path4835"
           style="font-size:12.69999981px;stroke-width:0.26458335"
           d="m 57.984794,162.72865 q -0.09922,-0.19843 -0.161231,-0.70693 -0.799951,0.83096 -1.909961,0.83096 -0.992187,0 -1.630908,-0.55811 -0.632519,-0.56431 -0.632519,-1.42627 0,-1.048 0.79375,-1.62471 0.799951,-0.58291 2.244824,-0.58291 h 1.116211 v -0.5271 q 0,-0.60151 -0.359668,-0.95498 -0.359668,-0.35966 -1.060401,-0.35966 -0.613916,0 -1.029394,0.31005 -0.415479,0.31006 -0.415479,0.75035 H 53.7866 q 0,-0.5023 0.353467,-0.96739 0.359668,-0.47129 0.967383,-0.74414 0.613916,-0.27285 1.345654,-0.27285 1.159619,0 1.816944,0.58291 0.657324,0.57671 0.682129,1.5937 v 3.08819 q 0,0.92397 0.235644,1.46967 v 0.0992 z m -1.90376,-0.87436 q 0.539502,0 1.023193,-0.27906 0.483692,-0.27905 0.700733,-0.72553 v -1.37666 h -0.89917 q -2.108399,0 -2.108399,1.23403 0,0.5395 0.359668,0.84336 0.359668,0.30386 0.923975,0.30386 z" />
        <path
           inkscape:connector-curvature="0"
           id="path4837"
           style="font-size:12.69999981px;stroke-width:0.26458335"
           d="m 60.483868,159.31801 q 0,-1.54409 0.731738,-2.48047 0.731738,-0.94258 1.916162,-0.94258 1.178223,0 1.866553,0.80615 v -3.49746 h 1.147216 v 9.525 h -1.054199 l -0.05581,-0.71933 q -0.68833,0.84336 -1.916162,0.84336 -1.165821,0 -1.90376,-0.95498 -0.731738,-0.95498 -0.731738,-2.49288 z m 1.147216,0.13022 q 0,1.14102 0.471289,1.78594 0.47129,0.64492 1.302247,0.64492 1.091406,0 1.593701,-0.97978 v -3.08199 q -0.514698,-0.94877 -1.581299,-0.94877 -0.843359,0 -1.314649,0.65112 -0.471289,0.65112 -0.471289,1.92856 z" />
        <path
           inkscape:connector-curvature="0"
           id="path4839"
           style="font-size:12.69999981px;stroke-width:0.26458335"
           d="m 67.627615,159.31181 q 0,-0.98599 0.384473,-1.77354 0.390674,-0.78755 1.079004,-1.21543 0.694531,-0.42788 1.581299,-0.42788 1.370459,0 2.213818,0.94878 0.849561,0.94878 0.849561,2.52388 v 0.0806 q 0,0.97979 -0.378272,1.76114 -0.37207,0.77514 -1.072803,1.20922 -0.694531,0.43409 -1.599902,0.43409 -1.364258,0 -2.213818,-0.94878 -0.84336,-0.94878 -0.84336,-2.51148 z m 1.153418,0.13642 q 0,1.11621 0.514698,1.79214 0.520898,0.67593 1.389062,0.67593 0.874365,0 1.389063,-0.68213 0.514697,-0.68833 0.514697,-1.92236 0,-1.10381 -0.5271,-1.78594 -0.520898,-0.68833 -1.389062,-0.68833 -0.849561,0 -1.370459,0.67593 -0.520899,0.67592 -0.520899,1.93476 z" />
        <path
           inkscape:connector-curvature="0"
           id="path4841"
           style="font-size:12.69999981px;stroke-width:0.26458335"
           d="m 79.081181,160.94892 q 0,-0.46509 -0.353467,-0.71934 -0.347266,-0.26045 -1.221631,-0.44648 -0.868164,-0.18604 -1.382861,-0.44649 -0.508497,-0.26045 -0.756543,-0.62012 -0.241846,-0.35966 -0.241846,-0.85576 0,-0.82475 0.694531,-1.39526 0.700733,-0.57051 1.785938,-0.57051 1.141015,0 1.847949,0.58911 0.713135,0.58911 0.713135,1.50689 h -1.153418 q 0,-0.47129 -0.403077,-0.81236 -0.396875,-0.34106 -1.004589,-0.34106 -0.626319,0 -0.979786,0.27285 -0.353466,0.27285 -0.353466,0.71314 0,0.41547 0.328662,0.62631 0.328662,0.21084 1.184424,0.40308 0.861962,0.19224 1.395263,0.45889 0.533301,0.26665 0.787549,0.64492 0.260449,0.37207 0.260449,0.91157 0,0.89917 -0.719336,1.44487 -0.719336,0.53951 -1.866552,0.53951 -0.806153,0 -1.42627,-0.28526 -0.620117,-0.28525 -0.973584,-0.79375 -0.347265,-0.51469 -0.347265,-1.11001 h 1.147216 q 0.03101,0.57671 0.458887,0.91778 0.434082,0.33486 1.141016,0.33486 0.651123,0 1.041797,-0.26045 0.396875,-0.26665 0.396875,-0.70693 z" />
      </g>
      <path
         d="m 42.030227,173.42077 a 7.9003706,3.961134 0 0 1 7.799141,-4.00997 7.9003706,3.961134 0 0 1 8.000317,3.90907 7.9003706,3.961134 0 0 1 -7.793905,4.01252 7.9003706,3.961134 0 0 1 -8.005418,-3.90644"
         sodipodi:open="true"
         sodipodi:end="3.1278744"
         sodipodi:start="3.1291834"
         sodipodi:ry="3.961134"
         sodipodi:rx="7.9003706"
         sodipodi:cy="173.37161"
         sodipodi:cx="49.929989"
         sodipodi:type="arc"
         id="path4844"
         style="opacity:1;fill:#ffffff;fill-opacity:1;fill-rule:nonzero;stroke:#130a06;stroke-width:1.62983334;stroke-miterlimit:4;stroke-dasharray:none;stroke-dashoffset:24;stroke-opacity:1" />
      <path
         d="m 46.615492,180.62107 a 4.6041656,4.717545 0 0 1 4.545172,-4.7757 4.6041656,4.717545 0 0 1 4.662412,4.65553 4.6041656,4.717545 0 0 1 -4.54212,4.77875 4.6041656,4.717545 0 0 1 -4.665385,-4.65241"
         sodipodi:open="true"
         sodipodi:end="3.1278744"
         sodipodi:start="3.1291834"
         sodipodi:ry="4.717545"
         sodipodi:rx="4.6041656"
         sodipodi:cy="180.56253"
         sodipodi:cx="51.219303"
         sodipodi:type="arc"
         id="path4849"
         style="opacity:1;fill:#ffffff;fill-opacity:1;fill-rule:nonzero;stroke:#130a06;stroke-width:1.44930804;stroke-miterlimit:4;stroke-dasharray:none;stroke-dashoffset:24;stroke-opacity:1" />
      <path
         d="m 50.732161,185.37992 a 2.6855335,2.7516658 0 0 1 2.651124,-2.78558 2.6855335,2.7516658 0 0 1 2.719507,2.71549 2.6855335,2.7516658 0 0 1 -2.649343,2.78737 2.6855335,2.7516658 0 0 1 -2.721242,-2.71367"
         sodipodi:open="true"
         sodipodi:end="3.1278744"
         sodipodi:start="3.1291834"
         sodipodi:ry="2.7516658"
         sodipodi:rx="2.6855335"
         sodipodi:cy="185.34578"
         sodipodi:cx="53.417488"
         sodipodi:type="arc"
         id="path4849-2"
         style="opacity:1;fill:#ffffff;fill-opacity:1;fill-rule:nonzero;stroke:#130a06;stroke-width:0.84535736;stroke-miterlimit:4;stroke-dasharray:none;stroke-dashoffset:24;stroke-opacity:1" />
    </g>
  </g>
</svg>
<?php /**PATH /home/vagrant/gomezsite2020/resources/views/site/partials/_svg-phantom.blade.php ENDPATH**/ ?>