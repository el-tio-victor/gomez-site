

<?php
if( $article === null ){
    $title          = old('title');
    $category_id    = old('category_id');
    $status         = old('status');
    $content        = old('content');
    $tags_u           = old('tags');
}
else{
    
    $title          = (old('title') != '')  ? old('title') : $article->title;
    $category_id    = (old('category_id') != '') ? old('category_id') : $article->category->id;
    $status         = (old('status') != '') ? old('status') : $article->status;
    $content        = (old('content') != '') ? old('content') : $article->content;
    $tags_u           = (old('tags') != '') ? old('tags') : $article_tags;
}
//variable para el estatus del post
$st_edited      = ( $status === 'edited' || $status === null )?true: false;
$st_publishes   = ( $status === 'published' )?true: false;
?>

<?php echo Form::open( ['route'=>$route ,'method'=> $method,'files'=>true] ); ?>

    <?php $__env->startComponent('dashboard.partials.card'); ?>
        <?php $__env->slot('header'); ?>
                <div class="col mb-0 d-flex form-group">
                    <?php echo Form::label('title','Titulo',['class'=>'col text-right']); ?>

                    <div class="col-8">
                        <?php echo Form::text("title",$title,['class'=>"form-control ".EnvatoHtml::invalidInput($errors->get('title')),'required'=>'required' ]); ?>

                        <?php echo $__env->make('dashboard.partials._errors-form',['errors',$errors,'name'=>'title'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    </div>
                </div>
        <?php $__env->endSlot(); ?>
        <?php $__env->slot('tools'); ?>    
        <?php $__env->slot('body'); ?>
                <div class="col mt-4 d-flex form-group">
                    <?php echo Form::label('category_id','Categoria',['class'=>'col text-right']); ?>

                    <div class="col-6">
                        <?php echo Form::select('category_id',$categories, $category_id,[
                        'class'=>'form-control '.EnvatoHtml::invalidInput($errors->get('category_id')),
                        'required',
                        'placeholder'=>'Seleccione ...']); ?>

                    </div>
                    
                </div>
                <div class="col  d-flex form-group">
                    <?php echo Form::label('status','Estado de articulo',['class'=>'col text-right']); ?>

                    
                    <div class='d-flex pl-2 col-6'>
                        <div class="custom-control custom-radio">
                        <?php echo Form::radio('status','edited',$st_edited,['id'=>'r1','class'=>'custom-control-input']); ?>

                        <?php echo Form::label('r1','En edición',['class'=>'custom-control-label']); ?>

                        
                        </div>
                        <div class="custom-control custom-radio ml-2">
                        <?php echo Form::radio('status','published',$st_publishes,['id'=>'r2','class'=>'custom-control-input']); ?>

                        <?php echo Form::label('r2','Publicado',['class'=>'custom-control-label']); ?>

                        </div>
                    </div>
                   
                </div>  
                <div  class="    form-group">
                    <?php echo Form::label('content','Contenido',['class'=>'col text-left']); ?>

                    <div class="col-12">
                        <div id='content' class=''>
                            <textarea name='content' value="<?php echo e(old('content')); ?>" 
                                class="textarea <?php echo e(EnvatoHtml::invalidInput($errors->get('content'))); ?>">
                            </textarea>
                        </div>
                    </div>
                </div>
                <div class="d-flex">
                    <div class="col col-md-6  d-flex  form-group">
                        <?php echo Form::label('tags','Tags'); ?>

                        <div class="col-8">
                            <?php echo Form::select('tags[]',$tags,$tags_u,['class'=>'form-control','multiple']); ?>

                        </div> 
                    </div>
                    <?php if( $article === null ): ?>
                    <div class="col col-md-6    d-flex form-group">
                        <?php echo Form::label('image','Imagen'); ?>

                        <div class="col-8">
                            <?php echo Form::file('image',['class'=>'btn btn-info']); ?>

                        </div>
                    </div>
                    <?php endif; ?>
                </div>
                
   
        <?php $__env->endSlot(); ?>
        <?php $__env->slot('footer'); ?> 
            <div class="col-xs-12  text-center">
                    <?php echo Form::submit('Crear',['class'=>'btn btn-success']); ?>

            </div>
        <?php $__env->endSlot(); ?>       
    <?php echo $__env->renderComponent(); ?>
<?php echo Form::close(); ?>


<?php $__env->startSection('js'); ?>
<script src="<?php echo e(asset('plugins/summernote/summernote-bs4.min.js')); ?>"></script>
<script>
  $(function () {
    // Summernote
    $('.textarea').summernote({height:320})
    $('.textarea').summernote('code',"<?php echo $content; ?>"  )
    <?php if ($errors->has('content')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('content'); ?>
        let editor = $('div.note-editor.note-frame')
        editor.css('border','solid 1px red')
        .before("<?php echo $__env->make('dashboard.partials._errors-form',['errors',$errors,'name'=>'content'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>")
    <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
  })
</script>
<?php $__env->stopSection(); ?><?php /**PATH /home/vagrant/gomezsite2020/resources/views/dashboard/blog/articles/_form.blade.php ENDPATH**/ ?>