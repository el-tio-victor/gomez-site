 
<section class="col-12 d-flex flex-column-reverse flex-md-row justify-content-center wrapper-blog">
    <div class="col-md-8 col-lg-7   gh ">
        <div class="d-flex justify-content-center flex-wrap articles-cont">
            <?php echo e($article); ?>

        </div>
        <div>
            <?php echo e($paginate); ?>

        </div> 
    </div>
     <aside class="col-md-4 aside-blog">
         <div class="aside-blog-wrapper">
            <?php echo $__env->make('site.blog.partials.contentCategories', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
		    <?php echo e($aside); ?>

         </div>
        
    </aside>
</section>
<?php /**PATH /home/vagrant/gomezsite2020/resources/views/site/blog/components/simple-panel.blade.php ENDPATH**/ ?>