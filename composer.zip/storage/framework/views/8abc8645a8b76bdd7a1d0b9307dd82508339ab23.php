

<?php $__env->startSection('header'); ?>
    <header>
        <?php $__env->startComponent('site.partials._nav-main'); ?>
        <?php echo $__env->renderComponent(); ?>
    </header>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script>
        var slash_top, slash_bottom, slash_middle, btn_menu
        window.onload = function(){
             btn_menu        = document.querySelector('.btn-menu')
            slash_top       = btn_menu.querySelector('.slash-top')
            slash_bottom    = btn_menu.querySelector('.slash-bottom')
            slash_middle    = btn_menu.querySelector('.slash-middle')
            btn_menu.addEventListener('click',showMenu)

            
        }
        function showMenu(){
            btn_menu.classList.toggle('active')
            let cont_menu = document.querySelector('.nav-main-items')
            cont_menu.classList.toggle('active')

            //slash de boton menu
            slash_top.classList.toggle('active')
            slash_bottom.classList.toggle('active')
            slash_middle.classList.toggle('active')
        }
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.site', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/vagrant/gomezsite2020/resources/views/site/index.blade.php ENDPATH**/ ?>