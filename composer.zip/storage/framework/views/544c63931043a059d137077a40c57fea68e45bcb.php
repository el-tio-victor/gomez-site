<?php if(auth::user()->admin()): ?>
    <li class=" <?php echo e(Request::is('dashboard/users','dashboard/users/*') ? ' active ' : ''); ?>">
        <a class="nav-link " href="<?php echo e(route('users.index')); ?>">
            <i class="icon-user"></i>
            <span>Usuarios</span>
        </a>    
    </li>
<?php endif; ?>
<li class=" <?php echo e(Request::is('dashboard/articles','dashboard/articles/*') ? ' active ' : ''); ?>">
    <a class="nav-link "
         href=" <?php echo e(route('articles.index')); ?> ">
        <i class="icon-newspaper"></i>
        <span>Atriculos</span>
    </a>
</li>
<li class=" <?php echo e(Request::is('dashboard/tags','dashboard/tags/*') ? ' active ' : ''); ?>">
    <a class="nav-link "
        href=" <?php echo e(route('tags.index')); ?> ">
        <i class="icon-price-tag"></i>
        <span>Tags</span>
    </a>
</li>

<li class=" <?php echo e(Request::is('dashboard/categories','dashboard/categories/*') ? ' active ' : ''); ?>" >
    <a class="nav-link " href=" <?php echo e(route('categories.index')); ?>" >
        <i class="icon-books"></i>
        <span>Categorias</span>
    </a>
</li>
<li class="treeview ">
          <a href="#"><i class="icon-image"></i> <span>Imágenes</span>
            <span class="pull-right-container">
                <i class="fa fa-angle-left pull-right"></i>
              </span>
          </a>
          <ul class="treeview-menu">
            <li class="<?php echo e(Request::is('dashboard/images') ? ' active ' : ''); ?>"><a href="<?php echo e(route('images.index')); ?>">Imágenes principales</a></li>
            <li class="<?php echo e(Request::is('dashboard/images/generals','dashboard/images/generals/*') ? ' active ' : ''); ?>"><a href="<?php echo e(route('images.indexGenerals')); ?>">Imagenes generales</a></li>
          </ul>
</li>
<?php /**PATH /home/vagrant/gomezsite2020/resources/views/dashboard/template/partials/navDashboardBlog.blade.php ENDPATH**/ ?>