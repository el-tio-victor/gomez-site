

<?php $__env->startSection('head-title'); ?>
 Blog
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
	<link rel="stylesheet" href=" <?php echo e(asset('css/style-home-blog.css')); ?> ">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content-meta-name-description'); ?>
    content="Blog de sitio Gomez-Site sobre desarrollo web y  diversos temas que no necesariamente son sobre 
    informatica" 
<?php $__env->stopSection(); ?>

<?php $__env->startSection('header'); ?>
    <?php $__env->startComponent('home.partials.header'); ?>
	<div class=" d-flex flex-column justify-content-center align-items-center">
		<div>	
			<h1>Articulos</h1>
		</div>
		<div>
			<?php if($filter->all()['filter'] == 'all'): ?>
           			<span class='f1 c-o p-1  bg-w'><i class='icon-filter '></i> Todos</span>
        		<?php elseif($filter->all()['filter'] == 'category'): ?>
            			<span class='border h1-filter '>
					<span class='f1  bg-w c-o'> 
						<i class='icon-books p-1'></i>Categoria
					</span>
					<span> <?php echo e($filter->all()['category_name']); ?></span>
				</span>
		        <?php elseif( $filter->all()['filter'] == 'tag' ): ?>
            			<span class='border h1-filter '>
					<span class='f1  bg-w c-o'> 
						<i class='icon-price-tag p-1'></i>Tag
					</span>
					<span> <?php echo e($filter->all()['tag_name']); ?></span>
				</span>
       			<?php endif; ?> 
		</div>
	</div>
    <?php echo $__env->renderComponent(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <?php $__env->startComponent('home.blog.components.simple-panel'); ?>
	<?php $__env->slot('filter',$filter); ?>
        <?php $__env->slot('article'); ?>
                <?php $__currentLoopData = $articles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $article): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <article class="col-10 col-sm-6    article">
                        <div class='card   card-image-cont'>
                            <?php $__currentLoopData = $article->images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <a href="<?php echo e(route('blog.article',$article->slug)); ?>">
                                    <img src="<?php echo e(asset('images/articles/'.$image->name)); ?>"
                                    alt="<?php echo e($article->title.' blog gomez-ste'); ?>" class='card-img-top'
                                    >
                                </a>
				<script async defer data-pin-hover="true" src="//assets.pinterest.com/js/pinit.js"></script>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                            
                        
                        <div class="article-ribbon">
                             <a href="">
                                <span class="badge badge-category">
                                    <i class="icon-books f-75"></i>
                                    <?php echo e($article->category->name); ?>

                                </span>
                            </a>
                        </div>
                        <h3> <?php echo e($article->title); ?> </h3>
                        <span>
                            <i class="icon-clock"></i>&nbsp;<?php echo e($article->updated_at->diffForHumans()); ?>

                        </span>
                        <div class="article-text">
                            <p> <?php echo $article->summary; ?> </p>
                        </div>
                        <a href="<?php echo e(route('blog.article',$article->slug)); ?>">
                            <span class='article-more-link'>
                                Ver Mas
                                <i class="transition icon-arrow-right2"> </i>
                            </span>
                        </a>
                        <footer class="row  ">        
                            <span class="d-flex align-items-center badge badge-light ">
                            
                            </span>
                        </footer>
                    </article>
                     
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                
        <?php $__env->endSlot(); ?>
        <?php $__env->slot('paginate'); ?>
            <nav aria-label="navigation border border-success ">
                    <?php echo e($articles->links()); ?>

            </nav>
        <?php $__env->endSlot(); ?>
	  <?php $__env->slot('aside'); ?>
            <strong class=' m-1 color-black   fb_p'><i class='f1-5 icon-facebook2'></i> Síguenos en facebook</strong>
            <div class='text-center fb_container'>
                
               <div class="fb-page m-auto" data-href="https://www.facebook.com/GomezSite/" data-tabs="" data-small-header="false"                   data-adapt-container-width="true" data-hide-cover="false" data-show-facepile="false">
			<blockquote cite="https://www.facebook.com/GomezSite/" class="fb-xfbml-parse-ignore">
		<a  ' href="https://www.facebook.com/GomezSite/"><span id='fb_a'>Gomez-Site</span></a></blockquote>
	       </div> 
            </div>
        <?php $__env->endSlot(); ?>
    <?php echo $__env->renderComponent(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script src=" <?php echo e(asset('js/scenesHeaderScrollMagic.js')); ?> "></script>
    <script src=" <?php echo e(asset('js/scenesAsideBlogScrollMagic.js')); ?>   ">
    </script>
  <div id="fb-root"></div>
    <script>(function(d, s, id) {

	if($(window).innerWidth() > 768){
      var js, fjs = d.getElementsByTagName(s)[0];
      if (d.getElementById(id)) return;
      js = d.createElement(s); js.id = id;
      js.src = 'https://connect.facebook.net/es_LA/sdk.js#xfbml=1&version=v3.0';
      fjs.parentNode.insertBefore(js, fjs);
	}
	else{
		$('#fb_a').html("<a href='https://www.facebook.com/GomezSite/' target='_blanck'> <i class='icon-facebook'></i>facebook.com/GomezSite/</a>" )
	}
    }(document, 'script', 'facebook-jssdk'));</script>
 
<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer'); ?>
    <?php echo $__env->make('template.partials.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('template.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/vagrant/gomezsite2020/resources/views/site/blog/partials/contentArticles.blade.php ENDPATH**/ ?>