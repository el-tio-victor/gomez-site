<table class="table">
    <thead>
        <tr>
            <th>#</th>
            <th>Nombre</th>
            <th>...</th></tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $tools; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tool): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($loop->index +1); ?></td>
                <td> <?php echo e($tool->tool_name); ?> </td>
                <td>
                    <div class="btn-group">
                        <a href="<?php echo e(route('tools.destroy',$tool->id)); ?>" class="btn btn-danger p-0 pl-1 pr-1"><i class="fas fa-trash"></i></a>
                        <a href=""  data-id_tool='<?php echo e($tool->id); ?>' data-tool_name='<?php echo e($tool->tool_name); ?>' class="btn btn-warning p-0 btn-edit-tool"><i class="fas fa-edit"></i></a>
                    </div>
                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table><?php /**PATH /home/vagrant/gomezsite2020/resources/views/dashboard/works/technologies/partials/_tools-body.blade.php ENDPATH**/ ?>