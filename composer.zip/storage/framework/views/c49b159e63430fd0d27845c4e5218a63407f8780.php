

<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('css/login.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <section class="d-flex justify-content-center align-items-center login-wrapper">
        <section class=" d-flex justify-content-center align-items-center">
            <div class='panel-left'></div>
            <div class='panel-form'>
                <?php $__env->startComponent('auth.partials._form'); ?>
                    <?php $__env->slot('errors',$errors); ?>
                <?php echo $__env->renderComponent(); ?>
            </div>
        </section>
    </section>
    
    

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.site', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/vagrant/gomezsite2020/resources/views/auth/login.blade.php ENDPATH**/ ?>