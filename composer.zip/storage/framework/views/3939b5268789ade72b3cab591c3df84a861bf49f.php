
<?php $pag_title = 'Tecnologías y Herramientas'; ?>

<?php $__env->startSection('title-doc', $pag_title); ?>

<?php $__env->startSection('title'); ?>
    <?php echo e($pag_title); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('breadcrumb-items'); ?>
    <li class="breadcrumb-item active"><?php echo e($pag_title); ?></li>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
	<?php echo $__env->make('flash::message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
	
    
    <?php echo $__env->make('dashboard.works.technologies.partials._tech-wrapper', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<script src="<?php echo e(asset('js/dashboard/works/techs/tech-edit.js')); ?>">
</script>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/vagrant/gomezsite2020/resources/views/dashboard/works/technologies/index.blade.php ENDPATH**/ ?>