<?php  $val = ($old_val_input != null)? $old_val_input : old($name_input); /*if(count($errors) > 0)dd($errors);*/ ?>
<div class='col'>
<?php echo Form::open(['method'=>'POST', 'route'=>$route ]); ?>

	<?php echo Form::label($name_input,$label_text); ?>

	<div class='input-group input-group-sm'>
		<?php echo Form::text($name_input, $val ,['class'=>'form-control '.EnvatoHtml::invalidInput($errors->get($name_input)),'placeholder'=>$placeholder,'required','required']); ?>

		<?php echo $__env->make('dashboard.partials._errors-form',['errors',$errors,'name'=> $name_input], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
		<span class="input-group-append">
            
             <?php echo Form::submit('Guardar',['class'=>'btn btn-success btn-flat']); ?>

        </span>
	</div>
	<?php if(isset($id_tech)): ?>
		<input name="id_technology" type="hidden" value="<?php echo e($id_tech); ?>">
	<?php endif; ?>
	<?php if($label_text === 'Actualizar Categoría'): ?>
    	<input name="_method" type="hidden" value="PUT">
    <?php endif; ?>
<?php echo FORM::close(); ?>

</div><?php /**PATH /home/vagrant/gomezsite2020/resources/views/dashboard/works/categoriesWork/partials/_form.blade.php ENDPATH**/ ?>