
    <?php echo Form::label("$name","$label",['class'=>'col text-right']); ?>

    <div class="col-8">

        <?php if($tag == 'password'): ?>
            <?php echo Form::$tag("$name",['class'=>'form-control', 'placeholder'=>"$placeholder", $required]); ?>


            <?php else: ?>
            <?php echo Form::$tag("$name",$data,['class'=>'form-control', 'placeholder'=>"$placeholder", $required]); ?>

        <?php endif; ?>
         
                  
    </div>  
    
<?php /**PATH /home/vagrant/gomezsite2020/resources/views/dashboard/template/partials/form.blade.php ENDPATH**/ ?>