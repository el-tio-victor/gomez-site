<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <title>Gomez-Site | <?php echo $__env->yieldContent('title',''); ?></title>
        <?php echo $__env->yieldContent('css'); ?>
        
    </head>
    <body>
        <?php $__env->startSection('header'); ?>
        <?php echo $__env->yieldSection(); ?>

        <main>
            <?php $__env->startSection('content'); ?>
            <?php echo $__env->yieldSection(); ?>
        </main>
        

        <?php $__env->startSection('footer'); ?>
        <?php echo $__env->yieldSection(); ?>
    </body>

    <?php echo $__env->yieldContent('js'); ?>  
</html>
<?php /**PATH /home/vagrant/gomezsite2020/resources/views/layouts/site.blade.php ENDPATH**/ ?>