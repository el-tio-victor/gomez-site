
<div class='d-flex justify-content-center align-items-center no-results-wrapper'>

  <?php echo $__env->make('site.partials._svg-phantom', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</div>
<?php /**PATH /home/vagrant/gomezsite2020/resources/views/site/partials/_no-results.blade.php ENDPATH**/ ?>