
    <?php
        if( $route ===  'tags.store'){
            $name = old('name');
        }
        else{
            $name  = (old('name') != '')  ? old('name') : $tag_edit->name;
        }
    ?>

<div class="">
    <?php echo Form::open(['route'=>$route, 'method'=>$method ]); ?>

        <div class="col  form-group">
            <?php echo Form::label('name','Nombre',['class'=>'col ']); ?>

            <div class="">
                <?php echo Form::text('name',$name,['class'=>'form-control '.EnvatoHtml::invalidInput($errors->get('name')),'placeholder'=>'Nombre del Tag','required']); ?> 
                <?php echo $__env->make('dashboard.partials._errors-form',['errors',$errors,'name'=>'name'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>
        </div>
        
        <div class="col  form-group ">
            <?php echo Form::submit('Guardar',['class'=>'btn btn-sm btn-success']); ?>

        </div>
    <?php echo Form::close(); ?>

</div>
<?php /**PATH /home/vagrant/gomezsite2020/resources/views/dashboard/blog/tags/_form.blade.php ENDPATH**/ ?>