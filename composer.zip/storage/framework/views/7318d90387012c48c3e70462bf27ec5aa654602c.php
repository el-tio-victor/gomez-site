
	
	<?php
        
        
        // Si esta definida la var id se esta editando una tech (despues de un error de val)
        if( isset($id) ){
        	$label_text = 'Actualizar Categoría';
        	$old_val_input = $old_val_input;
        	$id_edit = $id;
        	$route = ['categoriesWork.update',$id];
        }
        else{
        	$old_val_input = null;
        	$label_text = 'Nueva Categoría';
       		$route = 'categoriesWork.store';
        	
        }
        
    ?>

<section class="row tech-wrapper">
    <div class="col-md-6">
    	
        <?php $__env->startComponent('dashboard.partials.card'); ?>
            <?php $__env->slot('header','Categorias'); ?><?php $__env->slot('tools'); ?><?php $__env->endSlot(); ?>
            <?php $__env->slot('body'); ?>
            	<?php echo $__env->make('dashboard.works.categoriesWork.partials._form',[
            		'name_input'=>'categoryWork_name','route'=>$route,'label_text'=>$label_text,
            		'placeholder' =>'categoria1,categoria2,categoria3',
            		'old_val_input' => $old_val_input
            	], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <?php echo $__env->make('dashboard.works.categoriesWork.partials._catego-body', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php $__env->endSlot(); ?>
            <?php $__env->slot('footer'); ?>
            	<?php if(! is_array($categoriesWork)): ?> 
            		<?php echo $categoriesWork->render(); ?>

            	<?php endif; ?> 
            <?php $__env->endSlot(); ?>
        <?php echo $__env->renderComponent(); ?>
    </div>
    
</section><?php /**PATH /home/vagrant/gomezsite2020/resources/views/dashboard/works/categoriesWork/partials/_catego-wrapper.blade.php ENDPATH**/ ?>