
    <?php
        if( $route ===  'categories.store'){
            $name = old('name');
        }
        else{
            $name  = (old('name') != '')  ? old('name') : $category_edit->name;
        }
    ?>
    <div class="">
    
        <?php echo Form::open( ['route'=>$route,'method'=>$method] ); ?>

        <?php echo Form::label("name","Nombre ",['class'=>'col ']); ?>

            <div class="col form-group">
            
                <?php echo Form::text("name",$name,['class'=>'form-control '.EnvatoHtml::invalidInput($errors->get('name')), 'placeholder'=>"Nombre Categoría",'required'=>'required']); ?>

                <?php echo $__env->make('dashboard.partials._errors-form',['errors',$errors,'name'=>'name'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>
            <div class="col form-group">
            <?php echo Form::submit('Guardar',['class'=>'btn btn-sm btn-success']); ?>

            </div>
        <?php echo Form::close(); ?>

    </div>
    

<?php /**PATH /home/vagrant/gomezsite2020/resources/views/dashboard/blog/categories/_form.blade.php ENDPATH**/ ?>