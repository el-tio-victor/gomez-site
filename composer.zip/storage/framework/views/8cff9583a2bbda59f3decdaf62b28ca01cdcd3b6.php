

<table class="table">
    <thead>
        <tr>
             <?php echo e($thead); ?>

        </tr>
    </thead>
        <tbody>
            <?php echo e($tbody); ?>

        </tbody>
</table><?php /**PATH /home/vagrant/gomezsite2020/resources/views/dashboard/template/components/table.blade.php ENDPATH**/ ?>