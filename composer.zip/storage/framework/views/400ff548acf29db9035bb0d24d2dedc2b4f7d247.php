
<?php if( !isset($class_card)) $class_card = ''; ?>
<div class="card <?php echo e($class_card); ?>">
  <div class="card-header">
    <?php echo e($header); ?>

    <div class="card-tools">
      <!-- Buttons, labels, and many other things can be placed here! -->
      <?php echo e($tools); ?>

    </div>
    <!-- /.card-tools -->
  </div>
  <!-- /.card-header -->
  <div class="card-body">
    <?php echo e($body); ?>

  </div>
  <!-- /.card-body -->
  <div class="card-footer">
    <?php echo e($footer); ?>

  </div>
  <!-- /.card-footer -->
</div><?php /**PATH /home/vagrant/gomezsite2020/resources/views/dashboard/partials/card.blade.php ENDPATH**/ ?>