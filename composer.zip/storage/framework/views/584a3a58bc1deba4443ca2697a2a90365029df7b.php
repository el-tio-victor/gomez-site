

<?php $__env->startSection('title-doc','Imágenes'); ?>

<?php $__env->startSection('title'); ?>
    Imágenes
<?php $__env->stopSection(); ?>

<?php $__env->startSection('breadcrumb-items'); ?>
    <li class="breadcrumb-item active">Imágenes</li>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
   <div>
     <h3 class='text-center'>Imagenes Principales</h3>
        <div class="row justify-content-around">
       
            <?php $__currentLoopData = $images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            
                <?php $__env->startComponent('dashboard.partials.card', ['class_card'=>'col-md-3 ml-1 p-0']); ?>
                    <?php $__env->slot('header'); ?><?php echo e($image->title); ?><?php $__env->endSlot(); ?>
                    <?php $__env->slot('tools',''); ?>
                    <?php $__env->slot('body'); ?>
        
                            <img class="card-img-top " src="/images/articles/<?php echo e($image->name); ?> " alt="Card image cap">
                    <?php $__env->endSlot(); ?>
                    <?php $__env->slot('footer',''); ?>
                    <?php echo $__env->renderComponent(); ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div> 
   </div>
    
   
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/vagrant/gomezsite2020/resources/views/dashboard/blog/images/index.blade.php ENDPATH**/ ?>