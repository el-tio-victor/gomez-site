
<?php $pag_title = 'Editar trabajo'; ?>

<?php $__env->startSection('title-doc', $pag_title); ?>

<?php $__env->startSection('title'); ?>
    <?php echo e($pag_title); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
	<link href="https://cdn.jsdelivr.net/npm/select2@4.1.0-beta.1/dist/css/select2.min.css" rel="stylesheet" />
	<style>
	   .select2-search__field:focus{
	       border:none!important;
	   }
	</style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('breadcrumb-items'); ?>
    <li class="breadcrumb-item "><a href="/dashboard/works"> Proyectos </a></li>
    <li class="breadcrumb-item active"><?php echo e($work->title); ?></li>
    
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
 <?php echo Form::open(['route'=>['works.update',$work],'method'=>'PUT']); ?>

	<?php $__env->startComponent('dashboard.partials.card'); ?>
		
		<?php $__env->slot('header'); ?> 
			<div class="form-group d-flex ">
                <?php echo Form::label('title','Titulo',['class'=>' col']); ?>

                <div class="col-11">
                    <?php echo Form::text('title',$work->title,['
                        placeholder'=>'Titulo de Trabajo',
                        'class'=>'form-control']); ?>

                    <?php if($errors->has('title')): ?>
                        <span class="help-block">
                            <?php echo e($errors->first('title')); ?>

                        </span>
                    <?php endif; ?>
                </div>
            </div>
		<?php $__env->endSlot(); ?>

        <?php $__env->slot('tools'); ?>
            
        <?php $__env->endSlot(); ?>

        <?php $__env->slot('body'); ?>
        	<div class="form-group">
           		<?php echo Form::label('categoryWork_name','Tecnologías y Herramientas',['class'=>' col']); ?>

           		<div class="select2-purple col-8">
           			<?php echo Form::select('id_categoryWork',$categoryWork,$work->id_categoryWork,['class'=>'select2 form-control ']); ?>

           		</div>
            	 
            </div>
            	
            <div class="form-group">
           		<?php echo Form::label('techs','Tecnologías y Herramientas',['class'=>' col']); ?>

           		<div class="select2-purple col-8">
           			<?php echo Form::select('techs[]',[],[],['class'=>'select2 form-control techs','multiple']); ?>

           		</div>
            	 
            </div>	
            <div class="form-group d-flex flex-column">
                <?php echo Form::label('detail','Descripción',['class'=>' col']); ?>

                <div class="col-12">
                    <?php echo Form::textarea('detail',$det = old('detail') ? old('detail'): $work->detail ,['
                        placeholder'=>'descripción del trabajo del trabajo',
                        'class'=>'form-control textarea']); ?>

                    <?php if($errors->has('detail')): ?>
                        <span class="help-block">
                            <?php echo e($errors->first('detail')); ?>

                        </span>
                    <?php endif; ?>
                </div>
                
            </div>
            <div class="form-group d-flex flex-column">
                <?php echo Form::label('url','Url',['class'=>'col']); ?>

                <div class="col-8">
                    <?php echo Form::text('url',$work->url ,['
                        placeholder'=>'URL no obligatorio',
                        'class'=>'form-control']); ?>

                    <?php if($errors->has('detail')): ?>
                        <span class="help-block">
                            <?php echo e($errors->first('detail')); ?>

                        </span>
                    <?php endif; ?>
                </div>
                
            </div>
        <?php $__env->endSlot(); ?>
        
        <?php $__env->slot('footer'); ?>
        	<?php echo Form::submit('Crear',['class'=>'btn btn-success']); ?>

        <?php $__env->endSlot(); ?>
	<?php echo $__env->renderComponent(); ?>
 <?php echo Form::close(); ?>

   
     
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-beta.1/dist/js/select2.min.js"></script>
    <script src="<?php echo e(asset('plugins/summernote/summernote-bs4.min.js')); ?>"></script>
	<script>
		$('document').ready(function(){
            $('.textarea').summernote({height:320})
            
            //$('.textarea').summernote('code', '<?php echo $work->detail; ?>' )
			//Cuando la pag esta lista hago una consulta ajax para saber la lista de tech
			$.ajax({
				url: '/dashboard/techtool/list',
				dataType: 'json',
				delay: 250,
				data: { 'id_work': <?php echo e($id_work); ?> },
				success:function(data){
					//si la petición fue exitosa le cargo al select2 de las tech el resultado
					$('.techs').select2({
        				placeholder:'Selecciona',
            				data: data
        			})
					
				}
			})
		})

	</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/vagrant/gomezsite2020/resources/views/dashboard/works/work/edit.blade.php ENDPATH**/ ?>