

<?php $pag_title = 'Nuevo Proyecto'; ?>

<?php $__env->startSection('title-doc', $pag_title); ?>

<?php $__env->startSection('title'); ?>
    <?php echo e($pag_title); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
	<link href="https://cdn.jsdelivr.net/npm/select2@4.1.0-beta.1/dist/css/select2.min.css" rel="stylesheet" />
	<style>
	   .select2-search__field:focus{
	       border:none!important;
       }
       .select2-container--default .select2-selection--single {
           padding: inherit;
       }
	</style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('breadcrumb-items'); ?>
    <li class="breadcrumb-item "><a href="/dashboard/works"> Proyectos </a></li>
    <li class="breadcrumb-item active">Nuevo Proyecto</li>
    
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<?php echo Form::open(['route'=>'works.store','method'=>'post','files'=>true]); ?>

	<?php $__env->startComponent('dashboard.partials.card'); ?>
		
		<?php $__env->slot('header'); ?> 
			<div class="form-group d-flex">
                <?php echo Form::label('title','Titulo',['class'=>'text-right col']); ?>

                <div class="col-11">
                    <?php echo Form::text('title',old('title'),['
                        placeholder'=>'Titulo de Trabajo',
                        'class'=>'form-control','required'=>'required']); ?>

                    <?php if($errors->has('title')): ?>
                        <span class="help-block">
                            <?php echo e($errors->first('title')); ?>

                        </span>
                    <?php endif; ?>
                </div>
            </div>
		<?php $__env->endSlot(); ?>

        <?php $__env->slot('tools'); ?>
            
        <?php $__env->endSlot(); ?>

        <?php $__env->slot('body'); ?>
         
         	<div class="form-group d-flex">
                
                <?php echo Form::label('categoryWork_name','Categoría',['class'=>' col']); ?>

           		<div class="select2-purple col-8">
           			<?php echo Form::select('id_categoryWork',$categoryWork,old('id_categoryWork'),['class'=>'select2 form-control categoryWork','required'=>'required']); ?>

           		</div>
               
            </div>
        	 <div class="form-group d-flex">
                
                <?php echo Form::label('techs','Tecnologías y Herramientas',['class'=>' col']); ?>

           		<div class="select2-purple col-8">
           			<?php echo Form::select('techs[]',[],old('techs'),['class'=>'select2 form-control techs','multiple','required'=>'required']); ?>

           		</div>
               
            </div>
            <div class="form-group d-flex flex-column">
                <?php echo Form::label('detail','Descripción',['class'=>' col']); ?>

                <div class="col-12">
                    <?php echo Form::textarea('detail',old('detail'),['
                        placeholder'=>'descripción del trabajo del trabajo',
                        'class'=>'form-control textarea','required'=>'required']); ?>

                    <?php if($errors->has('detail')): ?>
                        <span class="help-block">
                            <?php echo e($errors->first('detail')); ?>

                        </span>
                    <?php endif; ?>
                </div>
                
            </div>
            <div class="form-group d-flex">
                <?php echo Form::label('url','Url',['class'=>' col']); ?>

                <div class="col-8">
                    <?php echo Form::text('url',null,['
                        placeholder'=>'Url opcional',
                        'class'=>'form-control']); ?>

                    <?php if($errors->has('detail')): ?>
                        <span class="help-block">
                            <?php echo e($errors->first('detail')); ?>

                        </span>
                    <?php endif; ?>
                </div>
                
            </div>
            <div class='form-group border'>
            	<?php echo Form::label('','Imágenes',['class'=>'text-left col']); ?>

            	 <div class=" d-flex justify-content-around  form-group">
                    <div>
                    	<?php echo Form::label('img','Principal',['class'=>'text-left col']); ?>

                        <div class="col-8">
                            <?php echo Form::file('img'); ?>

                            <?php if($errors->has('img')): ?>
                                <span class="help-block">
                                    <?php echo e($errors->first('img')); ?>

                                </span>
                            <?php endif; ?>
                        </div>
                    </div>
                    <div>
                    	<?php echo Form::label('img','Grales.',['class'=>'text-left col']); ?>

                        <div class="col-8">
                            <?php echo Form::file('imgs[]',['multiple']); ?>

                            <?php if($errors->has('img')): ?>
                                <span class="help-block">
                                    <?php echo e($errors->first('img')); ?>

                                </span>
                            <?php endif; ?>
                        </div>
                    </div>
                    
                    
                </div>
            </div>
           
        <?php $__env->endSlot(); ?>
        
        <?php $__env->slot('footer'); ?>
        	<div class="col border-top text-center p-1  footer-form">
                <?php echo Form::submit('Crear',['class'=>'btn btn-success']); ?>

            </div> 
        <?php $__env->endSlot(); ?>
        
    <?php echo $__env->renderComponent(); ?>
<?php echo Form::close(); ?>

  
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-beta.1/dist/js/select2.min.js"></script>
<script src="<?php echo e(asset('plugins/summernote/summernote-bs4.min.js')); ?>"></script>
	<script>
		$(document).ready(function(){
            $('.textarea').summernote({height:320})
			$('.techs').select2({
				placeholder:'Selecciona',
				ajax: {
					url: '/dashboard/techtool/list',
					dataType: 'json',
					delay: 250,
					// Additional AJAX parameters go here; see the end of this chapter for the full code of this example
					/*processResults: function (data) {
			            return {
			              results: data
			            };
			          },*/
				}
			})

			$('.categoryWork').select2()
		})
	</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/vagrant/gomezsite2020/resources/views/dashboard/works/work/create.blade.php ENDPATH**/ ?>