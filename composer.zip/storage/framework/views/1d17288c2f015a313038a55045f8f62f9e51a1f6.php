<nav class=' d-flex justify-content-around align-items-baseline pt-3 navbar-blog'>
    <div class="m-1 p-1   aside-categories">
        <span>CATEGORIAS</span>
        <ul>
            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <a href="<?php echo e(route( 'blog.search.category',$category->id )); ?>">
                <span class='badge badge-pill badge-light'>
                    <?php echo e($category->name); ?>&nbsp; <small class='badge badge-primary'><?php echo e($category->articles->count()); ?></small> 
                </span>
            </a>     
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>

    <div class="col-md-5  aside-tags">
        <span>TAGS</span>
        <ul>
            <?php $__currentLoopData = $tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <a href=" <?php echo e(route( 'blog.search.tag',$tag->id )); ?> ">
                    <span class='badge badge-pill badge-light'> <?php echo e($tag->name); ?> </span>
                </a>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
            

    </div>
</nav>

<?php /**PATH /home/vagrant/gomezsite2020/resources/views/site/blog/partials/contentCategories.blade.php ENDPATH**/ ?>