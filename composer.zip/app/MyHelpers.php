<?php
class MyHelpers{
    
    public static function saludo(){
        $msg = 'Que pedo perro';
        return $msg;
    }
    
    public static function versionAuto( $url ){
        $path       = pathinfo( $url );
        $version    = '?v='.filemtime($_SERVER['DOCUMENT_ROOT'].$url);
        return $path['dirname'].'/'.$path['basename'].$version; 
    }    

}
