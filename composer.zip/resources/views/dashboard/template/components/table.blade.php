

<table class="table">
    <thead>
        <tr>
             {{$thead}}
        </tr>
    </thead>
        <tbody>
            {{$tbody}}
        </tbody>
</table>