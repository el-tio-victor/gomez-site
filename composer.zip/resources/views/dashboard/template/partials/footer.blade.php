<footer class='container-fluid text-center footer-master'>
    <strong>Todos los derechos reservados</strong>
</footer>