<div class='d-flex align-items-center justify-content-center btn-flat'>
    <span class='btn-text'>
       {{ $text_link }} 
    </span>
</div>
