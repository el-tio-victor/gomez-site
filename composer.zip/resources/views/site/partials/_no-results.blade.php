
<div class='d-flex justify-content-center align-items-center no-results-wrapper'>
{{--	<img width='150' src='{{asset('images/page/phantom.svg')}}'/> --}}
  @include('site.partials._svg-phantom')
</div>
