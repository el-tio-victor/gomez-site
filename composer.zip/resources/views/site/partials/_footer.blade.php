<footer class='text-center p-1 footer-main'>
    <span>Derechos reservados</span>
</footer>