@extends('layouts.site')

@section('css')
        <!--<link rel="stylesheet" href="{{asset('css/bootstrap.css')}}">-->
        <link rel="stylesheet" href="{{asset(MyHelpers::versionAuto('/css/main.css'))}}">
@endsection

@section('header')
        @component('site.partials._header')
            
            <div class='header-intro'>
                <h1>Gomez-Site</h1>
                <h2 class=' d-flex flex-column'>
                    <div class='text-right'><span>by</span> víctor gómez</div>
                    <div class=" pr-3 text-right social">
                        <i class='icon-linkedin'></i>
                        <i class='mr-1 ml-2 icon-codepen'></i>
                        <i class='icon-github'></i>
                        <i class="icon-facebook"></i>
                    </div>
                </h2>
                
            </div>
        @endcomponent
@endsection

@section('content')
    @include('site.home.partials._svg-img-intro')
    <section class="about">
        <div class=" container about-me">
            
            <div class='d-flex justify-content-center flex-column-reverse flex-md-row align-items-center'>
            	<div class='col-12 col-md-6 col-lg-5 mb-md-5 align-self-end '>
                	<h2 class='subt'>¿Qué cosa es víctor?</h2>
                    <p class='about-me-text '>
                        Mi nombre es Víctor Manuel. Desarrollador web, apacionado por todo el impacto visual que un buen diseño puede ocacionar. Creyente
                        de que las cosas bien hechas son las mejores
                    </p>
            	</div>
            	
                <img class=' col-7  col-md-5' src="{{asset('/images/page/avatar.svg')}}" alt="">
            </div>
            
        </div>
        <div class="about-skills  mb-5 container">
               <h2 class='mt-5 mb-5 subt'>Y sus habilidades...</h2>
                <div class="margin-top-bott-elem skills-wrapper">
                    <div class="d-flex flex-column flex-sm-row  justify-content-around skills1">
                        <div class=' d-flex justify-content-center align-items-center skill'>
                            <h3>HTML</h3>
                        </div>
                        <div class='  d-flex justify-content-center align-items-center  skill'>
                            <h3>CSS</h3>
                        </div>
                        <div class=' d-flex justify-content-center align-items-center skill'>
                            <h3>JAVASCRIPT</h3>
                        </div>
                    </div>
                    <div class="d-flex d-flex flex-column flex-sm-row  justify-content-around  skills2">
                        <div class='d-flex justify-content-center align-items-center skill'>
                            <h3>PHP</h3>
                        </div>
                        <div class=' d-flex justify-content-center align-items-center skill'>
                            <h3>SQL</h3>
                        </div>
                        
                    </div>
                </div>
        </div>
        <div class="mt-5  d-flex align-items-center justify-content-center">
        	<div class=" d-flex align-items-center justify-content-center btn-flat">
        		<span class='btn-text'>VER CV</span>
        	</div>
            
        </div>
        <div class="container  about-footer">            
        </div>
    </section>
    <section class='works'>
        <header class=" container  works-header">
            <h2 class='pt-md-5 mb-5 subt'>Últimos proyectos</h2>
            <div class="margin-top-bott-elem d-flex  flex-column flex-md-row justify-content-center align-items-center works-intro">
                <div class='col-md-4'><img class='col-12' src="{{asset('/images/page/code.svg')}}" alt=""> </div>
                <div class='col-8 col-sm-4 mt-3 mt-md-0 ml-md-5'><p>Estos son algunos de mis proyectos desarrollados.</p></div>
            </div>
        </header>
        <section class='works-contain container-fluid d-flex flex-column flex-lg-row justify-content-center align-items-center'>
            @include('site.home.partials.contentWorks')
        </section>
        <div class="pt-5 pb-5 d-flex align-items-center justify-content-center">
            <a href="{{route('portfolio')}}">
                <div class=" d-flex align-items-center justify-content-center btn-flat">
                    <span class='btn-text'>VER PORTAFOLIO</span>
                </div>
            </a>
        </div>
    </section>
@endsection

@section('footer')
    @include('site.partials._footer')
@endsection

@section('js')
    <script>
        var slash_top, slash_bottom, slash_middle, btn_menu,nav_main
        
        window.onload = function(){
            btn_menu        = document.querySelector('.btn-menu')
            slash_top       = btn_menu.querySelector('.slash-top')
            slash_bottom    = btn_menu.querySelector('.slash-bottom')
            slash_middle    = btn_menu.querySelector('.slash-middle')
            btn_menu.addEventListener('click',showMenu)
            nav_main = document.querySelector('.navbar-main')
            
        }
        window.addEventListener('scroll' ,function(){
            if( window.scrollY > 80 ){
                nav_main.classList.add('scroll-page')
            }
            else{
                nav_main.classList.remove('scroll-page')
            }
        }) 

        function showMenu(){
            btn_menu.classList.toggle('active')
            let cont_menu = document.querySelector('.nav-main-items')
            cont_menu.classList.toggle('active')

            //slash de boton menu
            slash_top.classList.toggle('active')
            slash_bottom.classList.toggle('active')
            slash_middle.classList.toggle('active')
        }
    </script>
@endsection
