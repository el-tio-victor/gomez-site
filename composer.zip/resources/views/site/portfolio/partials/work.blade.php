     <article class="mt-5 mb-5 mr-sm-3 ml-sm-3 d-flex flex-column   justify-content-center work">
        
        <div class="col-12 d-flex flex-column flex-nowrap p-0  work-info">
            <div class="work-info-wrapper ">
                <div class='mb-3 work-info-title '>
            		<h3 class='m-0 d-inline-block title '>{{$title }}</h3>
            		<span class="ml-3 d-inline-block line"></span>
            	</div>
            </div>
        </div>
        <div class="  d-flex align-items-start justify-content-center mt-2 mb-2   work-img">
                <div class="pl-4 pt-2 work-info-techs">
            		@foreach($tt as $techs_tool)
                      <span class='mr-1 badge badge-tech'> 
			@php $tool_name = $techs_tool->tool->tool_name;
				$tool_name = ( $tool_name === "N/A") ? "" : $tool_name ;
			 @endphp
			 {!! $techs_tool->technology->technology_name.' / ' . $tool_name  !!}
                      </span>
                    @endforeach
            	</div>
            @foreach($images as $image)
                <img class='col-sm-12 ' src="{{asset('images/works/'.$image->name)}}" alt="">
                
            @endforeach
        </div>
        <div class=' pt-3'>
            <a href="{{route('portafolio.work',$work_slug)}}">
                <div class="btn-trans-hand ">
                        <div class="trans-hand">
                            <i class="icon icon-point-right"></i>
                        </div>
                        <span class='pl-4'> Ver proyecto</span>
                    
                </div>
            </a>
        </div>
    </article>
