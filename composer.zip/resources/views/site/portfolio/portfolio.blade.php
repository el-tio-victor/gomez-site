@extends('layouts.site')

@section('css')
    <link rel="stylesheet" href="{{asset('css/bootstrap.css')}}">
    <link rel="stylesheet" href="{{asset('css/portfolio.css')}}">
@endsection

@section('header')
        @component('site.partials._header')
            <div class='header-intro d-flex flex-column align-items-center justify-content-center'>
                <!--<img class='col-10 col-sm-8 col-md-6 col-lg-5' src="{{asset('images/page/code.svg')}}" alt="">-->
                <h1 class='text-center'>Echa un vistazo a mis proyectos</h1>
            </div>
        @endcomponent
@endsection

@section('title','Portafolio')

@section('content')
    <section class="mt-5 mb-5  d-flex justify-content-center nav-categories-wrapper">
        <nav class=' nav justify-content-around categories-nav'>
        	@if( ! isset($slug) )
        		@php $class_active = 'active'; @endphp
        	@else
        		@php $class_active = ''; @endphp
        	@endif
            <li class='nav-item '><a href="{{route('portfolio')}}" class=" nav-link {{$class_active}}">TODOS</a></li>
            @foreach($categoriesWork as $cat)
            	@php
            		$class_active = '';
            		if(isset($slug)){
            			if($slug === $cat->categoryWork_slug)
            				$class_active = 'active';
            		}
            		
            	@endphp
            	<li class='nav-item'> <a href="{{route('portafolio.search.work',$cat->categoryWork_slug)}}" class=" nav-link {{ $class_active }}">{{ $cat->categoryWork_name }}</a> </li>
            @endforeach
        </nav>
    </section>
    
            
    @foreach($works as $work)
        @if( ($loop->index + 1) % 2 != 0)
        <section class=' works-contain container-fluid d-flex flex-column flex-lg-row justify-content-center align-items-start'> 
        @endif
            @component('site.portfolio.partials.work')
                @slot('title',$work->title)
                @slot('services', $work->services)
                @slot('detail',$work->detail)
                @slot('url', $work->url )
                @slot('images', $work->images()->where('image_main',1)->get() )
                @slot('tt', $work->technologyTool)
                @slot('work_slug', $work->slug )
            @endComponent
        @if( ($loop->index + 1) % 2 === 0 || $loop->last)
        </section>
        @endif
    @endforeach
<div class=" pb-5 d-flex justify-content-center paginate">
    @if( count($works) > 0)
    {{ $works->render()}}
    @else
	@component('site.partials._no-results')@endcomponent
    @endif
</div>

    
            
        
@endsection

@section('footer')
    @include('site.partials._footer')
@endsection

@section('js')
    <script>
        var slash_top, slash_bottom, slash_middle, btn_menu,nav_main
        window.onload = function(){
            btn_menu        = document.querySelector('.btn-menu')
            slash_top       = btn_menu.querySelector('.slash-top')
            slash_bottom    = btn_menu.querySelector('.slash-bottom')
            slash_middle    = btn_menu.querySelector('.slash-middle')
            btn_menu.addEventListener('click',showMenu)
            nav_main = document.querySelector('.navbar-main')
            
        }
        window.addEventListener('scroll' ,function(){
            if( window.scrollY > 80 ){
                nav_main.classList.add('scroll-page')
            }
            else{
                nav_main.classList.remove('scroll-page')
            }
        }) 

        function showMenu(){
            btn_menu.classList.toggle('active')
            let cont_menu = document.querySelector('.nav-main-items')
            cont_menu.classList.toggle('active')

            //slash de boton menu
            slash_top.classList.toggle('active')
            slash_bottom.classList.toggle('active')
            slash_middle.classList.toggle('active')
        }
    </script>
@endsection
