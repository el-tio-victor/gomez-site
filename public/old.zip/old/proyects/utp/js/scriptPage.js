/*Script principal recorrido virtual UTP
		V赤ctor Manuel G車mez Rodr赤guez
	*/ 
		var canvas,engine,Escenario,Camara,Modelo;
		var piePag=document.getElementById("piePag");
		  

		function initScene()
		{
			/*Evento boton ver video */
			
			canvas=document.getElementById("myCanvas");
			setWindow();
		 	engine = new BABYLON.Engine(canvas,true);
			 Escenario=new BABYLON.Scene(engine);
			 //inicializar camara con el nombre y un vector con la posici車n de inicio
			Camara=new BABYLON.FreeCamera("FreeCamera", new BABYLON.Vector3(14,2,56), Escenario);
			Escenario.activeCamera=Camara;
			//Camara.applyGravity=true;
			Camara.checkCollisions=true;
			Camara.speed = 0.01;//Velocidad de desplazamiento de la camara
		    
			Camara.attachControl(canvas);

			var skybox = BABYLON.Mesh.CreateBox("skyBox", 1000.0, Escenario);
				BABYLON.Effect.ShadersStore.gradientVertexShader = "precision mediump float;attribute vec3 position;attribute vec3 normal;attribute vec2 uv;uniform mat4 worldViewProjection;varying vec4 vPosition;varying vec3 vNormal;void main(){vec4 p = vec4(position,1.);vPosition = p;vNormal = normal;gl_Position = worldViewProjection * p;}";

				BABYLON.Effect.ShadersStore.gradientPixelShader = "precision mediump float;uniform mat4 worldView;varying vec4 vPosition;varying vec3 vNormal;uniform float offset;uniform vec3 topColor;uniform vec3 bottomColor;void main(void){float h = normalize(vPosition+offset).y;gl_FragColor = vec4(mix(bottomColor,topColor,max(pow(max(h,0.0),0.6),0.0)),1.0);}";
				
				var shader = new BABYLON.ShaderMaterial("gradient", Escenario, "gradient", {});
				shader.setFloat("offset", 10);
				shader.setColor3("topColor", BABYLON.Color3.FromInts(0,119,255));
				shader.setColor3("bottomColor", BABYLON.Color3.FromInts(240,240, 255));
				shader.backFaceCulling = false;
				skybox.material = shader;
			
				var ground = BABYLON.Mesh.CreateGround("ground", 300, 300, 300, Escenario);
					ground.material = new BABYLON.StandardMaterial("ground", Escenario);
					ground.material.diffuseColor = BABYLON.Color3.FromInts(193, 181, 151);
					ground.material.specularColor = BABYLON.Color3.Black();
					
					ground.position.x = -100;
					ground.position.y = -100;
					ground.position.z = 0;

					ground.receiveShadows = true;
					ground.checkCollisions = true;
		
		
		
		
			var LuzPoint = new BABYLON.HemisphericLight('light1', new BABYLON.Vector3(20,50,10),Escenario);
		    var LuzDirectional= new BABYLON.DirectionalLight("Omni", new BABYLON.Vector3(-2,50,2),Escenario);
			var prog=0;
			//Importar documento con las mayas y establecer colision a cada una
			BABYLON.SceneLoader.ImportMesh(null,"./", "pasillos1-1.babylon", Escenario, function (newMesh) { 
				for(var i=0;i<Escenario.meshes.length;i++)
				{
					Escenario.meshes[i].checkCollisions=true;
				}
		    
		},function(evt){
					if(evt.lengthComputable){
						prog = (evt.loaded * 100 / evt.total).toFixed()
						document.getElementById("preLoaderP").innerHTML = "<br>" + prog   + "%";
						if(prog == 100){
							preLoader = document.getElementById("preLoader");
							preLoader.style.display = "none";
							document.getElementById("myCanvas").style.opacity = "1";
							document.getElementById("barraProgreso").style.width=prog.toString()+"%";
						}
					}else{
						dlCount = evt.loaded / (1024 * 1024);
						dl = Math.floor(dlCount * 100.0) / 100.0;
						prog = dl * 100 / 111.53;
						document.getElementById("preLoaderP").innerHTML = "Sé paciente..." + dl + " MB cargados."; 
						document.getElementById("barraProgreso").style.width=prog.toString()+"%";
						if (dl == 111.53) {
							preLoader = document.getElementById("preLoader");
							preLoader.style.display = "none";
							document.getElementById("myCanvas").style.opacity = "1";
						}
					}
				});
		

		function setColision(malla)
		{
			
		    //Camara.ellipsoid = new BABYLON.Vector3(10,1,10);
				malla.intersectsMesh(Escenario.activeCamera, true);
                

                 Camara.ellipsoid = new BABYLON.Vector3(20,20,20);
                Camara.applyGravity=true;
                malla.checkCollisions = true;

		}
			
     
			engine.runRenderLoop(function(){Escenario.render();});

		}
		function setWindow()
		{
			/*alert();
			canvas = document.getElementById("myCanvas");*/
		 var tamanioVentana=(window.innerHeight*90)/100;
		 //console.log(tamanioVentana);
		 	canvas.style.height=tamanioVentana.toString()+"px";
		 	piePag.style.height=(window.innerHeight-tamanioVentana).toString()+"px";
		 	
				}

		
//		setWindow()
document.querySelector('.link-video').addEventListener('click', function () {
	window.stop();
	document.querySelector('body').innerHTML = 
	"<div class='video-container'>"+
		"<video src='utprender.mp4' autoplay width='400' >"+
			+"Tu navegador es muy viejo"
		+"</video>"
	+"</div>"
	
})
window.addEventListener("DOMContentLoaded",    function(){  initScene();  }, false    );
//initScene();