/**Script para establecer las escenas de plugin SCROLLMAGIC */
//init scroll magic

var controller = new ScrollMagic.Controller()

//pin scene header
var pinHeaderScene = new ScrollMagic.Scene({
    triggerElement: '.header',
    triggerHook: 0,
    duration: '10%'
})
.setPin('.header')
.addTo(controller)

//Nuevaescena para fijar header
var sc = new ScrollMagic.Scene({
    triggerElement: 'main',
    triggerHook: 0
})
.setClassToggle('.header', 'fixed')
.addTo(controller)

var sc_gs = new ScrollMagic.Scene({
    triggerElement: 'main',
    triggerHook: 0
})
.setClassToggle('#iso-gs', 'up')
.addTo(controller)

/*Fin de script escenas header scrollmagic*/

/*script responsive menu*/
document.querySelector('.hamb-menu').addEventListener('click',function(){
     document.querySelector('body').classList.toggle('oh')
     document.querySelector('html').classList.toggle('oh')
     element = document.querySelector('.nav-public')
     element.classList.toggle('show')
     document.querySelector('.icon-hamb').classList.toggle('show')
     // .classList.toggle('show')
           var e = document.querySelectorAll('.icon-item ')
           for( i=0; i<e.length; i++){
               e[i].classList.toggle('show')
           }
           var items = document.querySelectorAll('.nav-public li.nav-item ')
           for( i=0; i<items.length; i++){
               items[i].classList.toggle('sho')
           }
     })
/*fin script responsive menu*/
