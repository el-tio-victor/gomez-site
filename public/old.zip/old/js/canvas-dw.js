var iy = 50
var ix = 0
var up =true,right=true, to_up=true, enter = true
var element = document.querySelector('.canvas')
var ctx = element.getContext('2d')
ctx.beginPath()
ctx.lineWidth = 6
ctx.strokeStyle = '#444'
ctx.moveTo(0,50)


function mov(){
    if(iy >= 0 & up){
        ctx.lineTo(0,iy = iy-4)
        ctx.stroke()
        setTimeout('mov()',1)
    }
    else if(ix >= 0 & ix <= element.clientWidth & right){
        up = false
        ctx.lineTo(ix = ix+4,0)
        ctx.stroke()
        setTimeout('mov()',1)    
    }
    else if(iy <= element.clientHeight && to_up  ){
        right = false
        ctx.lineTo(350,iy = iy+4)
        ctx.stroke()
        setTimeout('mov()',1)    
    }
    else if(ix >= 0 && !right){
        to_up= false
        ctx.lineTo(ix = ix-4,224)
        ctx.stroke()
        setTimeout('mov()',1)    
    }
    else if(iy >= 176 && !to_up){
        ctx.lineTo(0,iy = iy-4)     
        ctx.stroke()
        setTimeout('mov()',1)    
    }
    
}
document.addEventListener('scroll',function(){
    if(document.documentElement.scrollTop > document.querySelector('.header').clientHeight & enter){
        enter = false
        mov()
    }
    
})
